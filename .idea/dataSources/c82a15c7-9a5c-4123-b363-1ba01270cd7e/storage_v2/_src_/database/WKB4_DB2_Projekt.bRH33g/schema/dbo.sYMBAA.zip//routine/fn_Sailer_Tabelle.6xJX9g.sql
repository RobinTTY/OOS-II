CREATE FUNCTION fn_Sailer_Tabelle ()
RETURNS TABLE
AS
RETURN (SELECT m.nickname, m.saison, SUM(p.punkte) AS punkte 
		FROM Sailer_Mitspieler AS m 
		INNER JOIN Sailer_Punkte AS p 
		ON m.id = p.mitspieler_id 
		GROUP BY m.nickname, m.saison 
		-- Order by needs to be in the statement that selects from the function
		)
;
go

