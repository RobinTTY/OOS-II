CREATE procedure dbo.Schmidt_spAusleihen
(@LNr int, @BNr int, @Anzahl int)
as
begin
	declare @ANr int;

	insert into Schmidt_Ausleihe (BNr, Autor, Titel)
		select BNr, Autor, Titel 
		from Schmidt_Buch 
		where BNr=@BNr

	set @ANr = (select max(ANr) from Schmidt_Ausleihe)

	update Schmidt_Ausleihe
	set LNr=@LNr 
	where BNr=@BNr and ANr=@ANr

	update Schmidt_Ausleihe
	set Nachname=(select Nachname from Schmidt_Leser where LNr=@LNr)
	where LNr=@LNr and BNr=@BNr

	update Schmidt_Ausleihe
	set Vorname=(select Vorname from Schmidt_Leser where LNr=@LNr)
	where LNr=@LNr and BNr=@BNr

	update Schmidt_Ausleihe
	set Anzahl=@Anzahl
	where LNr=@LNr and BNr=@BNr

	update Schmidt_Ausleihe
	set RDat=(select dbo.Schmidt_fRueckgabe())
	where LNr=@LNr and BNr=@BNr

	select*from Schmidt_Ausleihe where LNr=@LNr and BNr=@BNr
end


go

