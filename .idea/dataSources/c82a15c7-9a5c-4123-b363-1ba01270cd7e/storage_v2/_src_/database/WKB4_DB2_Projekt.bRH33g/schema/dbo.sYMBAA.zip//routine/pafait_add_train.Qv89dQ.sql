CREATE Procedure [dbo].[pafait_add_train]
	@BahnName varchar(255),
    @Start_Bahnhof varchar(255),
    @Ziel_Bahnhof varchar(255),
    @Fahrzeit varchar(255),
	@Ankunft varchar(255),
	@Abfahrt varchar(255)
AS
insert into WKB4_DB2_Projekt.dbo.pafait_fahrplan
Values(@BahnName,@Start_Bahnhof,@Ziel_Bahnhof,@Fahrzeit,@Ankunft,@Abfahrt);
print'Bahnstrecke angelegt <- Ausgabe vom Stored Procedure'

Return 0
go

