CREATE PROCEDURE dbo.ilpoit00_KraftstoffpreisAenderung
	@Grossraum varchar (10),
	@Diesel float(6),
	@Super float(6),
	@SuperE10 float(6)
	AS
	Begin
	Set NOCOUNT ON;
		If @Großraum is not null
			Begin
				------If @Diesel is not null
				Begin
		Update K
		Set K.KraftstoffPreis = @Diesel
		From dbo.ilpoit00_Kraftstoffpreise AS K
		Inner Join dbo.ilpoit00_Stationen As S
		On K.StationsID = S.StationsID
		Where S.Ort = @Grossraum And K.KraftstoffNr = 11
				End

				If @Super is not null and @SuperE10 is not null
				Begin
		Update K1
		Set K1.KraftstoffPreis = @Super
		From dbo.ilpoit00_Kraftstoffpreise AS K1
		Inner Join dbo.ilpoit00_Stationen As S1
		On K1.StationsID = S1.StationsID
		Where S1.Ort = @Grossraum And K1.KraftstoffNr = 51
		
		Update K2
		Set K2.KraftstoffPreis = @SuperE10
		From dbo.ilpoit00_Kraftstoffpreise AS K2
		Inner Join dbo.ilpoit00_Stationen As S2
		On K2.StationsID = S2.StationsID
		Where S2.Ort = @Grossraum And K2.KraftstoffNr = 101
				End
		End
	End
go

