CREATE PROCEDURE dbo.romuit02_ClearPlanes
AS DELETE FROM romuit02_Planes;
go

