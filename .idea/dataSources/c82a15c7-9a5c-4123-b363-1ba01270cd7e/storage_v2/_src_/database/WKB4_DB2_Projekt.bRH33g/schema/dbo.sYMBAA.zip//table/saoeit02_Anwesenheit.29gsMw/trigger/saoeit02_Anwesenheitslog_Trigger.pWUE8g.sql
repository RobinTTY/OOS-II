Create Trigger dbo.saoeit02_Anwesenheitslog_Trigger
on dbo.saoeit02_Anwesenheit
after delete
as 
begin 
Insert Into saoeit02_Anwesenheitslog

Select A_ID,
		Mit_ID,
		Datum,
		Anwesenheit
from deleted
end
go

