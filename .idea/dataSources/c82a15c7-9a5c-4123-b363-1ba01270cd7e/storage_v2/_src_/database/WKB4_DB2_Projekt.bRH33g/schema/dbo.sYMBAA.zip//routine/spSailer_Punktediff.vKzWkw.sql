
CREATE PROCEDURE spSailer_Punktediff
@nickname1 varchar(50),
@nickname2 varchar(50)
AS
BEGIN
DECLARE @punkte1 AS int
DECLARE @punkte2 AS int
	SELECT @punkte1 = punkte
	FROM fn_Sailer_Tabelle()
	WHERE nickname = @nickname1

	SELECT @punkte2 = punkte
	FROM fn_Sailer_Tabelle()
	WHERE nickname = @nickname2

	if @punkte1 > @punkte2
	SELECT @punkte1 - @punkte2 AS punktedifferenz
	else if @punkte2 >= @punkte1
	SELECT @punkte2 - @punkte1 AS punktedifferenz

END
go

