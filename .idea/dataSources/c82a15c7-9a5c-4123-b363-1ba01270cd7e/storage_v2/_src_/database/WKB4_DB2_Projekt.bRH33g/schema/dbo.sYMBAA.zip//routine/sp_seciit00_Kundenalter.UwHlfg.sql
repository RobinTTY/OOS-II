
Create PROCEDURE [dbo].[sp_seciit00_Kundenalter] 
@Alter int
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT name, vorname,  [Alter] from dbo.seciit00_Kundenliste
	WHERE [Alter] > @Alter



END
go

