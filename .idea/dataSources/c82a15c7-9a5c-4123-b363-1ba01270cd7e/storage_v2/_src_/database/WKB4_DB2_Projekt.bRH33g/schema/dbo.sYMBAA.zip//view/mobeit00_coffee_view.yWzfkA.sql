
CREATE VIEW dbo.mobeit00_coffee_view
AS
SELECT dbo.mobeit00_coffee.id, name, dbo.mobeit00_type.type AS beans_type, price
FROM dbo.mobeit00_coffee
INNER JOIN dbo.mobeit00_type ON dbo.mobeit00_coffee.type = dbo.mobeit00_type.id;
go

