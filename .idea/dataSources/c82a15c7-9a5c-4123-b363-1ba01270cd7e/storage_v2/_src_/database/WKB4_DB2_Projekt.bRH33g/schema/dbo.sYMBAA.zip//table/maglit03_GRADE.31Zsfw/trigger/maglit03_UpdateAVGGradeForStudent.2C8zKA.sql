CREATE TRIGGER dbo.maglit03_UpdateAVGGradeForStudent ON dbo.maglit03_GRADE
AFTER INSERT
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @no AS INT
	DECLARE @avg AS REAL
	DECLARE @newavg AS REAL
	DECLARE @matr AS INT
	DECLARE @grade AS REAL

	SELECT @matr = inserted.MATR, @grade = inserted.GRADE FROM inserted
	SELECT @no = COUNT(SUB) FROM dbo.maglit03_GRADE WHERE MATR = @matr
	SELECT @avg = AVGGRADE FROM dbo.maglit03_STUDENT WHERE MATR = @matr
	EXEC @newavg = dbo.maglit03_computeAVGGrade @no, @avg, @grade
	UPDATE dbo.maglit03_STUDENT SET AVGGRADE = @newavg WHERE MATR = @matr
END
go

