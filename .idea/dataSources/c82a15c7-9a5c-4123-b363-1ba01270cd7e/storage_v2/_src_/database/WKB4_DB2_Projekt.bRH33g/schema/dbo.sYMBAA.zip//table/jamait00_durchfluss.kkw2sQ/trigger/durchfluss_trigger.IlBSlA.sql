CREATE TRIGGER [dbo].[durchfluss_trigger]
ON [WKB4_DB2_Projekt].[dbo].[jamait00_durchfluss]
AFTER INSERT
AS
BEGIN
	UPDATE [WKB4_DB2_Projekt].[dbo].[jamait00_durchfluss]
	SET Durchfl_min = Durchfl_l_sec * 60;
	UPDATE [WKB4_DB2_Projekt].[dbo].[jamait00_durchfluss]
	SET Nivus_min = DurchflNiv_l_sec * 60;
	UPDATE [WKB4_DB2_Projekt].[dbo].[jamait00_durchfluss]
	SET Differenz = Durchfl_min - Nivus_min
	UPDATE [WKB4_DB2_Projekt].[dbo].[jamait00_durchfluss]
	SET Diff_proz = ABS(Differenz / Nivus_min)
END
go

