CREATE TRIGGER daglit01_trigger_done
ON daglit01_task
FOR DELETE
AS
BEGIN
	SET NOCOUNT ON
	INSERT INTO daglit01_task_done (done, duration, old_id, name, description, created, creator, asignee, project)
	SELECT CURRENT_TIMESTAMP, dbo.daglit01_duration(created, CURRENT_TIMESTAMP),  id_task, name, description, created, creator, asignee, project FROM deleted
END
go

