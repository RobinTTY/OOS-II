CREATE PROCEDURE [dbo].[villalilla_hardreset]
AS
	DELETE FROM [dbo].[villalilla_keys];
	DELETE FROM [dbo].[villalilla_games];
	DELETE FROM [dbo].[villalilla_bundles];
RETURN 0
go

