CREATE PROCEDURE dbo.Broeker_addPlaylist
@NR int,
@NAME varchar(255),
@MOTTO varchar(255)


AS
BEGIN 
	if @NR IN(SELECT PNR FROM dbo.Broeker_Playlist)
	BEGIN print 'Nummer schon vorhanden'
	END
		
	else 
	BEGIN
	INSERT INTO dbo.Broeker_Playlist(PNR, PNAME, MOTTO)
	VALUES (@NR, @NAME, @MOTTO);
	print 'Playlist mit der Nummer ' + cast (@NR as varchar(10)) + ' und dem Namen ' + @Name + ' wurde angelegt';
	END
END
go

