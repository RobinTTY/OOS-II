CREATE FUNCTION [dbo].[knopp_funcGetAllInfoFromSpecifÜbung]
(
@übung varchar(40)
)
RETURNS table
AS
       RETURN (select distinct(idinfo),übungen,gewicht,wiederholungen,datum from Knopp_tblInfo
join Knopp_tblÜbungen on Knopp_tblInfo.IDÜbungen = Knopp_tblÜbungen.IDÜbungen
and Knopp_tblÜbungen.Übungen = @übung
join Knopp_tblDatum on Knopp_tblInfo.IDDatum = Knopp_tblDatum.IDDatum
)
go

