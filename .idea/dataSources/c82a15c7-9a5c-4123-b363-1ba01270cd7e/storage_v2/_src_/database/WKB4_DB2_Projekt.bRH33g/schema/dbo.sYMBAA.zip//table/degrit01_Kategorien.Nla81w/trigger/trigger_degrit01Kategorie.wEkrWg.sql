CREATE trigger trigger_degrit01Kategorie
on dbo.degrit01_Kategorien
for update
as
begin

declare @updateKategorie varchar(40);

select @updateKategorie= dk.KName from dbo.degrit01_Kategorien as dk
print'Es wurde '+@updateKategorie+' geupdatetet.'
end
go

