CREATE FUNCTION bikait01_EintraegeAnzeigen
(
@param1 varchar(15)
)
RETURNS INT
AS
BEGIN
	declare @ergebnis int = NULL;
		IF @param1 = 'Buch'
			SELECT @ergebnis = COUNT(*) FROM bikait01_Buch;
		ELSE IF @param1 = 'Ausleiher'
			SELECT @ergebnis = COUNT(*) FROM bikait01_Ausleiher;
		ELSE IF @param1 = 'Leihe'
			SELECT @ergebnis = COUNT(*) FROM bikait01_Leihe;
		RETURN @ergebnis;
END;
go

