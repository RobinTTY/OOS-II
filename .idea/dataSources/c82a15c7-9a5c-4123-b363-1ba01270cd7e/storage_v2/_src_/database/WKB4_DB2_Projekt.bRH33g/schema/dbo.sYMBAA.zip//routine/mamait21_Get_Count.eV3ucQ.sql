CREATE Function mamait21_Get_Count
(
)
returns int
as
begin 

	declare @counter int = null;

	Select @counter = count (*) from [dbo].[mamait21_ToDo];

	return @counter;

end
go

