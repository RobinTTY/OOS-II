CREATE PROCEDURE jaolit00_procedure_preisjeware
AS
SELECT
    NR
,	BEZEICHNUNG
,	PREIS
,	VORRAT
,   preis*vorrat AS PreisJeWare
FROM jaolit00_ware
go

