-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[functionkakteen] 
(
	@gartenname varchar(255)

)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @gartenanzahl int

	-- Add the T-SQL statements to compute the return value here
	SELECT @gartenanzahl = count(gk.KakteenID)
	from nifeit00_Kakteen as k
	join nifeit00_GaertenKakteen as gk
	on k.KakteenID = gk.KakteenID
	join nifeit00_Gaerten as g
	on g.GaertenID = gk.GaertenID
	where g.name = @gartenname;
	IF (@gartenanzahl IS NULL)   
        SET @gartenanzahl = 0
 

	-- Return the result of the function
	RETURN @gartenanzahl

END
go

