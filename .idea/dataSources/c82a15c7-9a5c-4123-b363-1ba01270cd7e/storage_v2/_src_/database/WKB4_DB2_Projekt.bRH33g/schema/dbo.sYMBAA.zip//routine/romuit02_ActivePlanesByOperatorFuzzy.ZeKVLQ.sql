CREATE PROCEDURE
  dbo.romuit02_ActivePlanesByOperatorFuzzy
    @operatorName varchar(50)
AS SELECT id, icao, operator, species, posTime, latitude, longitude, speed, trak, altitude FROM romuit02_Planes
WHERE operator LIKE '%' + @operatorName + '%'
go

