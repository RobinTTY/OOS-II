CREATE VIEW daglit01_task_view AS
SELECT t.id_task id, t.name,t.created, t.description, p.name as projectname, a.username as creator, a2.username as asignee  FROM daglit01_task t, daglit01_project p, daglit01_account a, daglit01_account a2
WHERE t.project = p.id_project AND t.creator = a.id_account AND t.asignee = a2.id_account;
go

