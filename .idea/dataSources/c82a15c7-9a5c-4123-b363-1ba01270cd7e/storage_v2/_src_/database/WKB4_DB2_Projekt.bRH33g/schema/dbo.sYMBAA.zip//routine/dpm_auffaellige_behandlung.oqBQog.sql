CREATE PROCEDURE [dbo].[dpm_auffaellige_behandlung]
AS
select bh_id, tk_start, (DATEDIFF(DAY, tk_start,GETDATE())/7) as 'Überschreitung in Wochen', tk_done, bh_therapeut,  p_id, p_name, p_vorname, p_telefonnr
from dpm_patient
join dpm_behandlung
on p_id = bh_patient
join dpm_terminkalender
on tk_bh_id=bh_id
where DATEDIFF(w, tk_start,GETDATE())>13
and tk_done=0
go

