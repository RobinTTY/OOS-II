-- =============================================
-- Author:		Schneider, Nico
-- Create date: 09/12/2018
-- Description:	Anzeige bestimmter Inhalte
-- =============================================
CREATE PROCEDURE [dbo].[Schneider_Attraktionen_Auswahl] 
	-- Add the parameters for the stored procedure here
	@Alter int,
	@Groesse float
AS
BEGIN
    -- Insert statements for procedure here
	SELECT *
	FROM [dbo].[Schneider_Attraktionen] AS attrakt 
		WHERE attrakt.Mindestgroesse <= @Groesse
		AND (attrakt.Mindestalter <= @Alter
		OR attrakt.Mindestalter IS NULL);

END
go

