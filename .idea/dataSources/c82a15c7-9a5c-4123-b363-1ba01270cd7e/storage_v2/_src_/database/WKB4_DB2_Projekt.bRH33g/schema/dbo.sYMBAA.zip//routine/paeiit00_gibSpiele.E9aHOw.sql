
CREATE FUNCTION [dbo].[paeiit00_gibSpiele]
(	
	@gruppe varchar(1)
)
RETURNS TABLE 
AS
RETURN 
(
	select distinct a.name as nation1, b.name as nation2 , a.datum, a.uhrzeit, a.tore1,':' as dp ,a.tore2
	from ( 
		select name, natnr1, natnr2, format(datum,'dd.MM.yyyy') as datum, format(uhrzeit, 'hh\:mm') as uhrzeit, tore1, tore2
		from paeiit00_spiele 
		inner join paeiit00_nationen 
		on natnr1 = natnr
		where gruppe = @gruppe) as a
	inner join
	 (
		select name, natnr2 
		from paeiit00_spiele 
		inner join paeiit00_nationen 
		on natnr2 = natnr
		where gruppe = @gruppe) as b
	on a.natnr2 = b.natnr2
	
)
go

