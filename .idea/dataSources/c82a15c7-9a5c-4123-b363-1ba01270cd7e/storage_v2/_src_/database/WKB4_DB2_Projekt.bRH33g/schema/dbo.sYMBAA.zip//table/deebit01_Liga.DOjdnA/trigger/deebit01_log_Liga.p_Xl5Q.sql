/*create table deebit01_Verein(
V_ID int IDENTITY(1,1) Primary key, 
Name varchar(40),Liga int);*/

/*create table deebit01_Spiel(
Spiel_ID int IDENTITY(1,1)  Primary key, 
Spieltag int, Datum date, Uhrzeit time, Heim int,
Gast int, Tore_Heim int, Tore_Gast int);*/

/*create table deebit01_Liga(
Liga_Nr int IDENTITY(1,1) Primary key, 
Verband varchar(40), Erstaustragung date,
Meister int, Rekordspieler varchar(40),
Spiele_Rekordspieler int);*/

/*create table deebit01_Spieler(
Spieler_ID int IDENTITY(1,1) Primary key, 
Vereins_ID int, Trikot_Nr int, Spieler_Name varchar(40),
Land varchar(40),  Spiele int, Tore int , Vorlagen int);*/

/*create table deebit01_log(
ID int IDENTITY(1,1), Zeitstempel datetime, Hostname varchar(40), Username varchar(40),
aktionstyp varchar(40), Tabellenname varchar(40));
*/
--Select * from dbo.deebit01_log;
/*Set IDENTITY_Insert dbo.deebit01_Verein*/

/*drop Table dbo.deebit01_Liga;*/


/*delete dbo.deebit01_Verein where Name='10';*/



/*
create Trigger [dbo].[deebit01_log_verein]
on [dbo].[deebit01_Verein]
for Delete
as
begin
set nocount on
insert into [WKB4_DB2_Projekt].[dbo].[deebit01_log]
select CURRENT_TIMESTAMP, HOST_NAME(), SUSER_NAME(), 'DELETE','Verein'
from deleted
end
*/
create Trigger [dbo].[deebit01_log_Liga]
on [dbo].[deebit01_Liga]
for Delete
as
begin
set nocount on
insert into [WKB4_DB2_Projekt].[dbo].[deebit01_log]
select CURRENT_TIMESTAMP, HOST_NAME(), SUSER_NAME(), 'DELETE','Liga'
from deleted
end


go

