create procedure [dbo].[tanzgruppenstandort]
@Tanzgruppe varchar(50),
@Standort varchar(50)
as
select Tanzgruppenname, standort
from emayit01_Tanzgruppe, emayit01_Standort
Where Standort = @Standort;


go

