create view avgstunden (Projektbezeichnung, Durchschnittlicher_Stundensatz)
as 
(
select projektbezeichnung, sum((m.Stundensatz * ps.Stundenanzahl)) / sum(ps.Stundenanzahl) as avgstundensatz
from nisiit00_Projekte as p
join nisiit00_Rechnung as r
on p.PNr = r.PNr
join nisiit00_Position as ps
on r.RNr = ps.RNr
join nisiit00_Mitarbeiter as m
on ps.MNr = m.MNr
group by Projektbezeichnung)
;
go

