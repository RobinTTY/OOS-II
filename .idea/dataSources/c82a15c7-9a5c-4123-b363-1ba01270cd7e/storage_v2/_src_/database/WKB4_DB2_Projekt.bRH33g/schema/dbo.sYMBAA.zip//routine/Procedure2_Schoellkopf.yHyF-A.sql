Create Procedure dbo.Procedure2_Schoellkopf
AS
Select st.strafeID, s.vorname, s.name, sc.beschreibung, sc.betrag, st.datum
FROM dbo.Schoellkopf_Strafen as st
JOIN dbo.Schoellkopf_spieler as s
ON s.spielerID = st.spielerID
JOIN dbo.Schoellkopf_strafKatalog as sc
ON sc.beschreibungID = st.beschreibungID

go

