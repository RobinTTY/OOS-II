CREATE function [dbo].[anzahl_unter_bahnen]
(

)
returns INT
As 
Begin
declare @anzahl int;
select @anzahl = (Select count(distinct BahnName) from WKB4_DB2_Projekt.dbo.pafait_fahrplan)

return @anzahl 
End
go

