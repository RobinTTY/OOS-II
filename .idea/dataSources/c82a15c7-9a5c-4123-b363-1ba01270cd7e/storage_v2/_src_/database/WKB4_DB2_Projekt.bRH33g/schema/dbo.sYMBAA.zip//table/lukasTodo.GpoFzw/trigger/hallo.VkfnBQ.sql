CREATE TRIGGER hallo
ON [dbo].[lukasTodo]
FOR INSERT
AS 
BEGIN
SET NOCOUNT ON

      INSERT INTO dbo.lukas_log(Zeitstempel,Hostname,Username,aktionstyp,tabellenname) VALUES (CURRENT_TIMESTAMP,'lukas','user','INSERT','lukasTodo');
END
go

