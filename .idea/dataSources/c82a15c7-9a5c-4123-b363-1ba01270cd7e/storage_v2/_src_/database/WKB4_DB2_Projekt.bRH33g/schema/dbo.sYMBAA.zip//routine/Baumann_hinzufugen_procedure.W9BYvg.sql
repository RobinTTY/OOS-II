CREATE PROCEDURE
dbo.Baumann_hinzufügen_procedure
@hinzu int,
@name varchar(40),
@anzahl float,
@price float
AS
begin 
	if @hinzu = 1
	begin
		if exists (select CoinID From Baumann_Portfolio where CoinID = (select Baumann_Coins.CoinID from Baumann_Coins where Baumann_Coins.Name = @name))
		update Baumann_Portfolio
		set OwnedAmount = (OwnedAmount + @anzahl), ChangeAmount=@anzahl, lastBuySellPrice = @price
		where CoinID = (select CoinID from Baumann_Coins where @name = Name)
		else if not exists (select CoinID From Baumann_Portfolio where CoinID= (select Baumann_Coins.CoinID from Baumann_Coins where Baumann_Coins.Name = @name))
		insert into Baumann_Portfolio (CoinID, OwnedAmount, ChangeAmount, lastBuySellPrice)
		VALUES ((select CoinID from Baumann_Coins where Baumann_Coins.Name = @name), @anzahl, @anzahl, @price)
	end 
	else if @hinzu = 0
	update Baumann_Portfolio
	set OwnedAmount = (OwnedAmount - @anzahl), ChangeAmount=(0-@anzahl), lastBuySellPrice = (0-@price)
	where CoinID = (select CoinID from Baumann_Coins where @name = Name)
end;
go

