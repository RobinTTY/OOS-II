CREATE TRIGGER [dbo].[löseAus]
ON [dbo].[charit_literatur_bewertung]
AFTER INSERT
AS
	DECLARE @bew int, @newVal  varchar(200) 
	SELECT @newVal = litTitle FROM INSERTED;
	EXEC @bew = dbo.charit_bewertungsDurchschnitt @newVal;
	UPDATE charit_literatur
	SET bewertung = @bew
	WHERE title = @newVal;
go

