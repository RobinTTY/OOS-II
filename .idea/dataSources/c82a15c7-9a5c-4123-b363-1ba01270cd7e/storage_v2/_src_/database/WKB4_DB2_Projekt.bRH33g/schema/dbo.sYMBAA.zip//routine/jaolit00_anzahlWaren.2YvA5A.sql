create function jaolit00_anzahlWaren
()
returns int
as
begin
declare @anzahl int 
select @anzahl= sum(Vorrat)
from jaolit00_ware
return @anzahl

end;
go

