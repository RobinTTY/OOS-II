create trigger Zink_Ausgaben_logTrigger
on dbo.Zink_Ausgaben
for insert
as
begin
insert into dbo.Zink_logAusgaben (LogArt) values ('Insert')
end
go

