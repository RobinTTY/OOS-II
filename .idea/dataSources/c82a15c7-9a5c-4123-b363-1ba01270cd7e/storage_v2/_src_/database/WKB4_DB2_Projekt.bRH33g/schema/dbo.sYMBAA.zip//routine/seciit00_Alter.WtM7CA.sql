
CREATE FUNCTION [dbo].[seciit00_Alter] ( @KundenID varchar )
RETURNS float
AS
	BEGIN
		DECLARE @Alter float
		Select @Alter = (avg([Alter] ))
		FROM dbo.seciit00_Kundenliste
		WHERE KundenID = @KundenID; 
		RETURN @Alter
	END
go

