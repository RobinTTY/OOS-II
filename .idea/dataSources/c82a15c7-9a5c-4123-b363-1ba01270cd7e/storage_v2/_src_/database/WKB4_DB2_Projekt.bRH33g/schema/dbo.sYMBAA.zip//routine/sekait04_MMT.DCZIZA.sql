--Stored Procedure
/*
alter procedure 
dbo.sekait04_Stuttgart
AS
BEGIN
select count(*) as AnzahlMitgliederAusStuttgart
from sekait04_Mitglieder 
where Ort='Stuttgart';
END
GO

exec dbo.sekait04_Stuttgart;
*/



CREATE procedure 
dbo.sekait04_MMT
AS
BEGIN
select m.MitgliedID, m.Vorname, m.Nachname
from sekait04_Mitglieder AS m  
join sekait04_Termin AS t on m.MitgliedID = t.MitgliedID;
END
go

