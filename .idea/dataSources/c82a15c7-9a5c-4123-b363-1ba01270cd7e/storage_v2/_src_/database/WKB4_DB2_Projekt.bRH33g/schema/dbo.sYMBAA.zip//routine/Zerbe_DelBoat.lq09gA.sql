CREATE Procedure [dbo].[Zerbe_DelBoat]
(
@Bootnr int
)
AS
DECLARE @count int = 0

SELECT @count = count(*)
FROM Zerbe_Boot
WHERE Bootnr = @Bootnr

IF (@count = 1)
BEGIN
DELETE FROM Zerbe_Boot
WHERE  Bootnr = @Bootnr

PRINT 'Boot wurde aus der Liste entfernt.'

END
ELSE 
PRINT 'Bootnummer existiert nicht.';
go

