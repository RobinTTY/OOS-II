create procedure leugit00_Übersicht
as

select s.Vorname, Nachname, t.Hohenacker, t.Schozach,t.Bietigheim,t.Pfullingen,t.Oberhausen,t.Nordheim,t.Herrenberg from leugit00_Spieler as S
inner join leugit00_Tore as T
on s.Vorname=t.Vorname;
go

