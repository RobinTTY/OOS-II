CREATE PROCEDURE [dbo].[bauzit00_add_Gast]
@name varchar (40),
@kontaktdaten varchar (50)

AS

	INSERT INTO dbo.bauzit00_Tischreservierung_Gast
	VALUES (@name, @kontaktdaten)

RETURN 0
go

