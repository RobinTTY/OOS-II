Create Function		dbo.Höse_Function
(
					@Beer			INTEGER
)

Returns				Float

As

Begin

Declare				@Multi		Float		=		0;

Select				@Multi	=	(@Beer * 1.5);

Return				@Multi;

End
go

