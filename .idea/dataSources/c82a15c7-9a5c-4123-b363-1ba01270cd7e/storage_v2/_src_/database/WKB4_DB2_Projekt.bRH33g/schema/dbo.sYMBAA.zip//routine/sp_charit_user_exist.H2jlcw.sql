CREATE procedure [dbo].[sp_charit_user_exist]
@username varchar(10)
AS
IF NOT EXISTS 
( 
	SELECT  name
    FROM    charit_user
    WHERE   name = @username
) 
INSERT INTO charit_user(name)
VALUES(@username)
go

