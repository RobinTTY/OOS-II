CREATE procedure degrit01_wertSpiele2016
as 
select sum(preis) as GesamtPreis2016, count(Titel) as AnzahlSpiele2016
from dbo.degrit01_PS4Spiele as dp
join dbo.degrit01_Gekauft as dg 
on dp.PS4SpielNummer=dg.PS4SpielNummer
where KDatum like '2016%';
go

