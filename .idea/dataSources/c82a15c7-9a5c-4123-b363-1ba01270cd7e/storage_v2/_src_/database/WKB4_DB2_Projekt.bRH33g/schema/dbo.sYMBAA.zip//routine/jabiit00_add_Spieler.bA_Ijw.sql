CREATE PROCEDURE dbo.jabiit00_add_Spieler
@vorname varchar(50),
@name varchar (50),
@geburtstag date,
@position varchar (5),
@vereinsid int

AS

	INSERT INTO dbo.jabiit00_Spieler
	VALUES (@vorname, @name, @geburtstag, @position, @vereinsid)

RETURN 0
go

