create trigger trigger_degrit01
on dbo.degrit01_PS4Spiele
for insert
as
begin

declare @anzahlSpiele int;
declare @gesamtPreis float;

select @anzahlSpiele= count(Titel) from dbo.degrit01_PS4Spiele
select @gesamtPreis= sum(Preis) from dbo.degrit01_PS4Spiele
 print'Es wurden '+cast(@anzahlSpiele as varchar)+' Spiele mit einem Gesamtwert von '+cast(@gesamtPreis as varchar)+'€ im System erkannt.'
end
go

