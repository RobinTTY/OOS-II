-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER log_drohnen 
   ON  [WKB4_DB2_Projekt].[dbo].[vawait00_Drohnen] 
   FOR  DELETE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    INSERT INTO [WKB4_DB2_Projekt].[dbo].[vawait00_Drohnen_log] 
		SELECT CURRENT_TIMESTAMP, HOST_NAME(), SUSER_NAME(), 'DELETE', 'Drohnen', DrohnenID, Name, HerstellerID, maxGesch, Gewicht
		FROM deleted

END
go

