CREATE TRIGGER dbo.almait06_triggerInsertBestand
ON  dbo.almait06_Bestand 
INSTEAD OF INSERT
AS 
BEGIN
    SET NOCOUNT ON;
	DECLARE @ArtikelID int =null;
	SELECT @ArtikelID = MAX(ArtikelID) + 1 FROM dbo.almait06_Bestand
    INSERT INTO dbo.almait06_Bestand(ArtikelID, Artikelname,Menge,Kaufdatum)
    SELECT @ArtikelID,Artikelname,Menge,Kaufdatum
    FROM inserted
END
go

