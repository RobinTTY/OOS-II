--Stored Procedure
/*
alter procedure 
dbo.sekait04_Stuttgart
AS
BEGIN
select count(*) as AnzahlMitgliederAusStuttgart
from sekait04_Mitglieder 
where Ort='Stuttgart';
END
GO

exec dbo.sekait04_Stuttgart;
*/


/*
alter procedure 
dbo.sekait04_MMT
AS
BEGIN
select m.MitgliedID, m.Vorname, m.Nachname
from sekait04_Mitglieder AS m  
join sekait04_Termin AS t on m.MitgliedID = t.MitgliedID;
END
GO

exec dbo.sekait04_MMT;
*/

--Trigger
/*
create TRIGGER Termin
ON sekait04_Termin
FOR DELETE
AS 
BEGIN
	SET NOCOUNT ON
        delete from sekait04_Termin where MitgliedID IN (select MitgliedID from deleted);
END;

delete from sekait04_Mitglieder where MitgliedID = 12;

drop trigger trgTermin;
*/

create TRIGGER Trainer
ON dbo.sekait04_Termin
FOR INSERT
AS 
BEGIN 
	SET NOCOUNT ON 
	Declare @Anzahl int;

	Select @Anzahl = count(*) from sekait04_Trainer;

	print 'Derzeit gibt es ' + cast(@Anzahl as varchar) + 'Trainer ';
	 
END


SET IDENTITY_INSERT sekait04_Trainer ON insert into dbo.sekait04_Trainer (TrainerID, Vorname, Nachname) values (2,'Yusuf','Topal');

drop trigger Traineranzahl;
go

