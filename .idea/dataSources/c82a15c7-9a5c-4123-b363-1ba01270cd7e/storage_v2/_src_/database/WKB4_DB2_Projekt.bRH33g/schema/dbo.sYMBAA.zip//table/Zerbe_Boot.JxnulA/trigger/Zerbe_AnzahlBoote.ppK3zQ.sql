CREATE TRIGGER [dbo].[Zerbe_AnzahlBoote]
ON [dbo].[Zerbe_Boot]
FOR INSERT, DELETE
AS
BEGIN
SET NOCOUNT ON
DECLARE @AnzGesamt int;
DECLARE @AnzYacht int;
DECLARE @AnzTretboot int;
DECLARE @AnzKajak int;
DECLARE @AnzSegelboot int;

SELECT @AnzGesamt = count(Bootnr) FROM Zerbe_Boot;
SELECT @AnzYacht = count(Bootnr) FROM Zerbe_Boot
WHERE Typ = 'Yacht';
SELECT @AnzTretboot = count(Bootnr) FROM Zerbe_Boot
WHERE Typ = 'Tretboot';
SELECT @AnzKajak = count(Bootnr) FROM Zerbe_Boot
WHERE Typ = 'Kajak';
SELECT @AnzSegelboot = count(Bootnr) FROM Zerbe_Boot
WHERE Typ = 'Segelboot';

PRINT 'Derzeit sind '+cast(@AnzGesamt as varchar(3))+' Boote im Besitz: ' 
+cast(@AnzYacht as varchar(3)) + ' Yachten, '
+cast(@AnzTretboot as varchar(3)) + ' Tretboote, '
+cast(@AnzKajak as varchar(3)) + ' Kajaks und '
+cast(@AnzSegelboot as varchar(3)) + ' Segelboote.'
END
go

