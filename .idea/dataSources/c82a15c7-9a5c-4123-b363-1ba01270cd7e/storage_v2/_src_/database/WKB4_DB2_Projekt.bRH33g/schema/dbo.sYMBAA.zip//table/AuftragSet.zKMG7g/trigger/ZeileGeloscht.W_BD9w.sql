create trigger ZeileGelöscht
on dbo.AuftragSet 

for delete
as
begin
  set nocount on
  declare @ID int;
  declare @Wert int;
   
 
  
  select @ID = id from deleted
  select @Wert = Betrag from deleted
  



  insert into AuftragLog values (CURRENT_TIMESTAMP, HOST_NAME(), SUSER_NAME(),'Gelöscht', 'auftrag', @ID, @Wert)
   
end
go

