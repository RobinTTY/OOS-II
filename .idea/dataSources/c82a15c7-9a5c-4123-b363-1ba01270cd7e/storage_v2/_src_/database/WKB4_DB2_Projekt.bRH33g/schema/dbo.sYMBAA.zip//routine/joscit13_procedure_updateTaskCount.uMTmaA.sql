CREATE PROCEDURE
	dbo.joscit13_procedure_updateTaskCount
	AS
	BEGIN
		UPDATE dbo.joscit13_category SET tasks=dbo.joscit13_function_countTasks(dbo.joscit13_category.id);
	END
go

