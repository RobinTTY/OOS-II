create trigger [dbo].[log_Tischtennis]
on[WKB4_DB2_Projekt].[dbo].[flscit09_Tischtennis]
FOR Delete
as 
begin
set nocount on
insert into [WKB4_DB2_Projekt].[dbo].[flscit09_Log]
select current_timestamp, HOST_NAME(), SUSER_NAME(), 'DELETE', 'Tischtennis', ID from deleted end
go

