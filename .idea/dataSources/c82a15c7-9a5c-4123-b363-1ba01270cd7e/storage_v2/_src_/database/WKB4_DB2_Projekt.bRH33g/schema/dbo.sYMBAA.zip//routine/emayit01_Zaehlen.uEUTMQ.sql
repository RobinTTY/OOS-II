CREATE FUNCTION dbo.emayit01_Zaehlen
(
 @x varchar(30)
)
RETURNS INT
AS
BEGIN
declare @res int = NULL;
IF @x ='Tanzgruppenname'
 SELECT @res = COUNT(*) FROM emayit01_Tanzgruppe
ELSE IF @x ='Standort'
 SELECT @res = COUNT(*) FROM emayit01_Standort;

RETURN @res;
END
go

