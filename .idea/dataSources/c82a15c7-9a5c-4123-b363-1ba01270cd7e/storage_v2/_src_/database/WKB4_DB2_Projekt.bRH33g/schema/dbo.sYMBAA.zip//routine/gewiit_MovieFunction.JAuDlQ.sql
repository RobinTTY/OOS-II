CREATE FUNCTION [dbo].[gewiit_MovieFunction]()
RETURNS INT
AS
BEGIN
declare @var1 int;
select @var1 =  Sum([MovieLength in min])
From dbo.gewiit_Movies;
--insert code here
RETURN @var1
END;
go

