CREATE PROCEDURE [dbo].[seciit00_ZeigeAlleKunden]
as
BEGIN
SELECT * from dbo.seciit00_Kundenliste;
ENd
go

