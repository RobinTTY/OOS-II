
CREATE PROCEDURE [dbo].[paeiit00_add_user]
	-- Add the parameters for the stored procedure here
	@name varchar(30),
	@vorname varchar(30),
	@username varchar(20)

AS

DECLARE @userID INT;

BEGIN
	
		SELECT @userID = (count(*)+1)
		from paeiit00_person;
		IF NOT EXISTS(
			Select username 
			from paeiit00_person
			where username = @username
		)
		BEGIN
			select 'Benutzer angelegt';
			Insert INTO paeiit00_person 
			values(@userID, @name, @vorname, @username);
			
		END
		ELSE
		BEGIN
			select 'Benutzername schon vorhanden'
		END
END
go

