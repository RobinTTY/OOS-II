create function dbo.dpm_werte_therapeut_aus
(
@param1 int
)
returns int
as
begin

declare @toreturn int

set @toreturn = (
Select sum(tk_anzahl) 
From dpm_therapeut 
Join dpm_behandlung 
on t_id = bh_therapeut 
Join dpm_terminkalender
on bh_id=tk_bh_id
Where t_id= @param1
And tk_done = 1
)

return @toreturn

end
go

