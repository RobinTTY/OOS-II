--create procedure [dbo].[flscit09_Wettkampfsuche]


--@Halle varchar(10)

--as
--begin
--set nocount on


--	select ID, Tag, Datum, Uhrzeit, Liga, Heimmannschaft, Gastmannschaft, Ergebnis, Halle
--	from [dbo].[flscit09_tischtennis]
--	where Halle = @Halle;

--END

create function [dbo].[flscit09_Wettkampfsuche_function]

(@Halle int) returns int

as
begin

declare @Summe int

Select @Summe = Count(Halle) from dbo.flscit09_tischtennis
where Halle = @Halle

return @Summe

END

--select [dbo].[flscit09_Wettkampfsuche_function](4)


go

