CREATE PROCEDURE Erdenebileg_Lieferanten_Menge_Rabatt as

SELECT 
dbo.Erdenebileg_Lieferant.l_name AS Lieferant,
dbo.Erdenebileg_Rabatt.menge AS Menge,
dbo.Erdenebileg_Prozent( dbo.Erdenebileg_Rabatt.rabatt) AS Rabatt 
From Erdenebileg_Rabatt JOIN Erdenebileg_Lieferant On Erdenebileg_Rabatt.l_id=Erdenebileg_Lieferant.id
go

