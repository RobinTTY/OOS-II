create procedure [dbo].[flscit09_Wettkampfsuche]


@Halle varchar(10)

as
begin
set nocount on


	select ID, Tag, Datum, Uhrzeit, Liga, Heimmannschaft, Gastmannschaft, Ergebnis, Halle
	from [dbo].[flscit09_tischtennis]
	where Halle = @Halle;

END

--exec [dbo].[flscit09_Wettkampfsuche] 4


go

