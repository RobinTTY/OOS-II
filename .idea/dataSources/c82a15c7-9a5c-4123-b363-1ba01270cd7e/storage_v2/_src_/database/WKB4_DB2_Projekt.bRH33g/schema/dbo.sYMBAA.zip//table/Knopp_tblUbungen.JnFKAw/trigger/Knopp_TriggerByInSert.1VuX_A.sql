

CREATE TRIGGER Knopp_TriggerByInSert ON [dbo].[Knopp_tblÜbungen]
FOR  INSERT AS
BEGIN
  SET NOCOUNT ON
 select * from Knopp_tblÜbungen
END

go

