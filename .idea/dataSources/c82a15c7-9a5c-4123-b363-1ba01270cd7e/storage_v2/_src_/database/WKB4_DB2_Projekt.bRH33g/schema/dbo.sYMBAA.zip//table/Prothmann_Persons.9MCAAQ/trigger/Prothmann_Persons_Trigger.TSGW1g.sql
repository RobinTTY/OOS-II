create trigger dbo.Prothmann_Persons_Trigger on dbo.Prothmann_Persons after delete 
as
begin
insert into dbo.Prothmann_Deleted(
gelöscht,
Name,
Vorname,
Geburtsdatum)

select 
CURRENT_TIMESTAMP,
Name,
Vorname,
Geburtsdatum

from deleted

end
go

