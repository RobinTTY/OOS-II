create function dbo.Schlappa_Anzahl_Transaktion_1
()
returns int
as
begin
declare @anzahl int
select @anzahl = count(AID)
from dbo.Schlappa_Ausgaben
return @anzahl
end;
go

