CREATE PROCEDURE dbo.romuit02_ClearOldPlanes
    @time int
AS DELETE FROM romuit02_Planes WHERE posTime < DATEADD(minute, @time, GETDATE());
go

