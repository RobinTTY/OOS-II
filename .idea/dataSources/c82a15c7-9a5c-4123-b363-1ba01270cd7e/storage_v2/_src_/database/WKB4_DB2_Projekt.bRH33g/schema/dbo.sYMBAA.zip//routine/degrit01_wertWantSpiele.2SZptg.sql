CREATE function degrit01_wertWantSpiele
()
returns varchar(50)
as
begin
declare @wert float
declare @anzahl int
select @wert=sum(Preis), @anzahl=count(Titel)
from dbo.degrit01_WantPS4Spiele
return 'Ich will '+cast(@anzahl as varchar(20))+' Spiele im Wert von '+cast(@wert as varchar(20))+'€' 
end;
go

