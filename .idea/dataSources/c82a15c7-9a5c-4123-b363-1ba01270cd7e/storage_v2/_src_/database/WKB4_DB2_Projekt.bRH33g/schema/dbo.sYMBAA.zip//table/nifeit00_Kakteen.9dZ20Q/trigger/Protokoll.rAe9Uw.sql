-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[Protokoll] 
   ON  [WKB4_DB2_Projekt].[dbo].[nifeit00_Kakteen] 
   FOR  DELETE

AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

   INSERT INTO [WKB4_DB2_Projekt].[dbo].[nifeit00_Protokoll] 
		SELECT CURRENT_TIMESTAMP, HOST_NAME(), SUSER_NAME(), 'DELETE', 'Kakteen', KakteenID, Pflanzenname, Ursprungsland, Gattung, DuengerID
		FROM deleted

END
go

