create procedure dbo.Schmidt_spRuckgabe
(@ANr int)
as
begin
	delete from Schmidt_Ausleihe
	where @ANr=ANr
end
go

