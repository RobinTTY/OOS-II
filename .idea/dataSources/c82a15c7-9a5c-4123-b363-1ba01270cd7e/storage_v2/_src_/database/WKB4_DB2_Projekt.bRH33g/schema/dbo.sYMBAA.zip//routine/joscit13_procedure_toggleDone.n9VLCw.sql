CREATE PROCEDURE dbo.joscit13_procedure_toggleDone @id int
AS
	UPDATE dbo.joscit13_task SET done = CASE WHEN done=0 THEN 1 ELSE 0 END WHERE id=@id;
go

