create procedure [dbo].[tanzgruppenstandort2]
@StandortID varchar(50)
as
select Tanzgruppenname
from emayit01_Tanzgruppe
Where StandortID = @StandortID;


go

