CREATE FUNCTION zaehler
(@text varchar(500), 
 @leerzeichen int)

RETURNS INT
AS

BEGIN
  declare @ergebnis int = null;

  if @leerzeichen = 0
  select @ergebnis = LEN(REPLACE(@text,' ', ''))
  if @leerzeichen = 1
  select @ergebnis = LEN(@text);
 RETURN @ergebnis

END
go

