-- =============================================
-- Author:		Schneider, Nico
-- Create date: 09/12/2018
-- Description:	Anlegen einer Attraktion
-- =============================================
CREATE PROCEDURE [dbo].[Schneider_Attraktion_Anlegen]
	-- Add the parameters for the stored procedure here
	@parknummer int,
	@attraktionsname varchar(255),
	@themenbereich varchar(255),
	@kategorie varchar(255),
	@groesse float,
	@alter int
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	INSERT INTO [dbo].[Schneider_Attraktionen]
	VALUES (@parknummer, @attraktionsname, @themenbereich, @kategorie, @groesse, @alter)

END
go

