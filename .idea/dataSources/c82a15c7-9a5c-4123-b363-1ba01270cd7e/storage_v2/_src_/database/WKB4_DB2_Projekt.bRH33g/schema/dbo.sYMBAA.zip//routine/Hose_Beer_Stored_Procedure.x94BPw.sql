Create	Procedure	dbo.Höse_Beer_Stored_Procedure

					@Username			nvarchar(100),
					@Groupname			nvarchar(100)

As

Begin

					SELECT			Beer 
					
					FROM			dbo.Höse_Beer

					Where			U_ID = (SELECT U_ID FROM dbo.Höse_User Where U_Name = @Username) And
									G_ID = (SELECT G_ID FROM dbo.Höse_Group Where G_Name = @Groupname)

End;
go

