create function Schlappa_AnzahlTransaktion
()
returns int
as
begin
declare @anzahl int
select @anzahl = count(TAID)
from dbo.Schlappa_Ausgaben
return @anzahl
end;
go

