CREATE TRIGGER dbo.Broeker_PlaylistTrigger
ON dbo.Broeker_Verwaltung
FOR INSERT

AS
BEGIN 
declare @ANZAHL int;
declare @LAENGE float;
declare @PNR int;
declare @PLNR int;
/* Die Playlist zu der zuletzt etwas hinzugefügt wurde*/
select @PNR = (SELECT TOP 1 v2.PNR FROM dbo.Broeker_Verwaltung v2 ORDER BY v2.VNR DESC);
/*Anzahl der Titel in der Playlist*/
select @ANZAHL = (SELECT count(*) FROM dbo.Broeker_Verwaltung v1 WHERE v1.PNR = @PNR);
/*Gesamtlänge der Titel in der Playlist*/
select @LAENGE= ((SELECT sum(LAENGE) FROM dbo.Broeker_Titel t, dbo.Broeker_Verwaltung v WHERE t.TNR =v.TNR AND v.PNR = @PNR )/60);
/*Aufsteigende PLNR */ 
select @PLNR = (SELECT TOP 1 PLNR FROM dbo.Broeker_Playlist_Log ORDER BY PLNR DESC) + 1;

INSERT INTO dbo.Broeker_Playlist_Log (PLNR, PEINTRAG) VALUES (@PLNR, 'Derzeit sind ' + cast (@ANZAHL as varchar (5)) + ' Titel mit einer Gesamtlänge von etwa '+ cast(@LAENGE as varchar (10)) +' Minuten in der Playlist')

	/*print 'Derzeit sind ' + cast (@ANZAHL as varchar (5)) + ' Titel mit einer Gesamtlänge von etwa '+ cast(@LAENGE as varchar (10)) +' Minuten in der Playlist';*/
END


go

