CREATE procedure [dbo].[ZähleAufträge]
(
	@param1 bit
	
)


as
begin	
	if @param1 = 0	
	return select count(*) from AuftragSet where Status = 'Auftrag abgeschlossen'
	if @param1 = 1	
	return select count(*) from AuftragSet where Status = 'wird bearbeitet'

end

go

