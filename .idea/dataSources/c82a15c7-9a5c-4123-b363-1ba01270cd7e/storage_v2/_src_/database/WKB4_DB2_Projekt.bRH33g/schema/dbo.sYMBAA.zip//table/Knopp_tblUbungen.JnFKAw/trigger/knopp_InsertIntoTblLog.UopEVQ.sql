CREATE TRIGGER knopp_InsertIntoTblLog ON [dbo].[knopp_tblübungen]
FOR INSERT AS
BEGIN
  SET NOCOUNT ON
 declare @id int;
declare @übung varchar(30);

select @übung = übungen from Knopp_tblÜbungen 
where IDÜbungen = (select max(IDÜbungen) from Knopp_tblÜbungen)
select @id = idübungen from Knopp_tblÜbungen 
where IDÜbungen = (select max(IDÜbungen) from Knopp_tblÜbungen)
insert into knopp_tbllog (id,übung,datum)
values (@id,@übung,CURRENT_TIMESTAMP)

END
/*insert into Knopp_tblÜbungen (IDÜbungen,Übungen)
values (6,'b')*/


go

