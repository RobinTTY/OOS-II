CREATE FUNCTION dbo.Broeker_AnzahlTitel (@name varchar(255))
RETURNS int

AS 
BEGIN 
	DECLARE @anzahl int = (SELECT count(*) FROM dbo.Broeker_Titel t, dbo.Broeker_Interpret i
							WHERE t.INR = i.INR AND i.INAME = @name);
	/*DECLARE @ILNR int = (SELECT TOP 1 ILNR FROM dbo.Broeker_Interpret_Log ORDER BY ILNR DESC);*/
	
	RETURN @anzahl;
END
go

