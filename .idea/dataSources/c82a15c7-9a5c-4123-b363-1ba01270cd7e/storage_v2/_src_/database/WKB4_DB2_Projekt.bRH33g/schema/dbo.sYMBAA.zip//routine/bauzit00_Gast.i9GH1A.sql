CREATE PROCEDURE dbo.bauzit00_Gast
   (@ID int)
AS
BEGIN
    INSERT INTO dbo.bauzit00_Tischreservierung_Gast(ID, Name, Kontaktdaten) 
        SELECT ID, Name, Kontaktdaten 
        FROM dbo.bauzit00_Tischreservierung
        WHERE ID = @ID
END
go

