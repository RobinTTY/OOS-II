Create Procedure dbo.Procedure_Schoellkopf
AS
Select s.spielID, s.spielerID, sp.vorname, sp.name as Nachname,s.bahnID,s.schläge, s.datum
from dbo.Schoellkopf_Spiele as s
JOIN dbo.Schoellkopf_Spieler as sp
ON s.spielerID = sp.spielerID
go

