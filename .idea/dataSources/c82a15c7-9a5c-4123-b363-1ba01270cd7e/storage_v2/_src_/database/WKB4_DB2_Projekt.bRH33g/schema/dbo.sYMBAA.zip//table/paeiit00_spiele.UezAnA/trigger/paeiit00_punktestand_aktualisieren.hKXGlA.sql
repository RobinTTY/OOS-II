CREATE TRIGGER dbo.paeiit00_punktestand_aktualisieren ON dbo.paeiit00_spiele
	AFTER UPDATE 

AS 
DECLARE @spn int, @tore1 int, @tore2 int, @pn int, @wtor1 int, @wtor2 int

SELECT @spn = spn from inserted ;
SELECT @tore1 = tore1 from inserted;
SELECT @tore2 = tore2 from inserted;
Select @pn = count(*) from paeiit00_person;

while(@pn>0)
Begin
	IF EXISTS(
		SELECT pn
		from paeiit00_wetten
		where spn = @spn
		and pn = @pn
	)
	BEGIN
		SELECT @Wtor1 = wtor1 from paeiit00_wetten where pn = @pn and spn = @spn;
		SELECT @Wtor2 = wtor2 from paeiit00_wetten where pn = @pn and spn = @spn;

		IF(@tore1 = @wtor1 AND @tore2 = @wtor2)
		BEGIN
			UPDATE dbo.paeiit00_position
			SET punkte = punkte +5
			where pn = @pn
		END

		ELSE IF(@tore1-@tore2 =  @wtor1-@wtor2 )
		BEGIN
			UPDATE dbo.paeiit00_position
			SET punkte = punkte +3
			where pn = @pn
		END

		ELSE IF(@tore1 > @tore2 AND @wtor1 > @wtor2)
		BEGIN
			UPDATE dbo.paeiit00_position
			SET punkte = punkte +1
			where pn = @pn
		END

		ELSE IF(@tore1 < @tore2 AND @wtor1 < @wtor2)
		BEGIN
			UPDATE dbo.paeiit00_position
			SET punkte = punkte +1
			where pn = @pn
		END
	END

SET @pn = @pn-1
END


go

