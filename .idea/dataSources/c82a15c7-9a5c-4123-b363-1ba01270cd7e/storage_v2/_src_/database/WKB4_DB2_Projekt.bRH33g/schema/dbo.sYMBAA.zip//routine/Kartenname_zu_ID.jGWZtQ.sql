Create function dbo.Kartenname_zu_ID(@Kartenname varchar(30))
Returns int
as  begin

	declare @kartenid int;
	Select  @kartenid = mk.KID from maskit_Karte as mk Where Kname = @KartenName
	Return	@kartenid

END
go

