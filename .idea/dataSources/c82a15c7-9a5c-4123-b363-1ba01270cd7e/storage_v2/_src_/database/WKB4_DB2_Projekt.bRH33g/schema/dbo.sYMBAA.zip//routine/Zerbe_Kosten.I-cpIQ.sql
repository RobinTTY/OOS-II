CREATE FUNCTION [dbo].[Zerbe_Kosten]
(
	@Typ varchar(20),
	@Zeit int
)
RETURNS INT 
AS BEGIN
DECLARE @Ergebnis int = NULL;
SELECT @Ergebnis = @Zeit * (SELECT Stundenpreis
							FROM Zerbe_Preis
							WHERE Typ = @Typ)
RETURN @Ergebnis;
END
go

