-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[paeiit00_add_wette]
	-- Add the parameters for the stored procedure here
	@spn int,
	@username varchar(30),
	@wtor1 int,
	@wtor2 int
AS

declare @pn int;

Set nocount on;

BEGIN

	select @pn = pn 
	from paeiit00_person
	where username = @username;

	



    -- Insert statements for procedure here
	IF(@wtor1 is not null AND @wtor2 is not null)
	BEGIN
		DELETE from paeiit00_wetten 
		where pn = @pn and spn = @spn;
		--DBCC CHECKIDENT ( paeiit00_wetten, RESEED, 0) 

		insert into paeiit00_wetten
		values(@spn, @pn, @wtor1, @wtor2);
		select 'Wette angelegt';
	END
	ELSE
		select 'nicht korrekt eingegeben';
END
go

