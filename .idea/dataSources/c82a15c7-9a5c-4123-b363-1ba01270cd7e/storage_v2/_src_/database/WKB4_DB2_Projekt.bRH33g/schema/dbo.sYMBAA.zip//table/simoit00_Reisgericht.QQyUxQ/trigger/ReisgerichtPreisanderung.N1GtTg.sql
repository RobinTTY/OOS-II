--CREATE TABLE dbo.simoit00_Reisgericht
--(ReisID int IDENTITY PRIMARY KEY,
-- Bezeichnung varchar(255),
-- Preis money);
 
--CREATE TABLE dbo.simoit00_Bedienung
--(BedienungID int IDENTITY PRIMARY KEY,
-- Nachname varchar(255),
-- Vorname varchar(255));

--CREATE TABLE dbo.simoit00_Bestellung
--(BestellungID int IDENTITY PRIMARY KEY,
-- TischnummerID int,
-- ReisID int,
-- NudelnID int);
 
--CREATE TABLE dbo.simoit00_Tischnummer
--(TischnummerID  int IDENTITY PRIMARY KEY,
-- BedienungID int); 
 
--CREATE TABLE dbo.simoit00_Nudelngericht
--(NudelnID int IDENTITY PRIMARY KEY,
-- Bezeichnung varchar(255),
-- Preis money);


--ALTER TABLE dbo.simoit00_Bestellung
--ADD CONSTRAINT FK_Bestellung --name des FK
--FOREIGN KEY (TischnummerID) REFERENCES dbo.simoit00_Tischnummer(TischnummerID),
--FOREIGN KEY (ReisID) REFERENCES dbo.simoit00_Reisgericht (ReisID),
--FOREIGN KEY (NudelnID) REFERENCES dbo.simoit00_Nudelgericht (NudelnID);

--ALTER TABLE dbo.simoit00_Tischnummer
--ADD CONSTRAINT FK_Tischnummer
--FOREIGN KEY (BedienungID) REFERENCES dbo.simoit00_Bedienung (BedienungID);

 --INSERT INTO dbo.simoit00_Reisgericht(Bezeichnung,preis)
 --VALUES
 --('Thai Basilikum ', 7.50 ),
 --('Gelbes curry ', 6.70 ),
 --('Rotes Curry',6.70),
 --('Gebratener Reis', 5.50),
 --('tom ka kai',  5.50);

 --INSERT INTO dbo.simoit00_Nudelgericht(Bezeichnung,preis)
 --VALUES
 --('Nudelsuppe mit Rind', 7.50 ),
 --('Nudelsuppe mit Haehnchen ', 6.70 ),
 --('Padthai',9.70),
 --('Gebratene Reisnudeln', 5.50),
 --('Glasnudelsalat',  5.50);

 --INSERT INTO dbo.simoit00_Bedienung(Nachname,Vorname)
 --VALUES
 --('Tantika',' Kauwnopparat'),
 --('Mayuree','Sammmor'),
 --('sarawut',' maikao');

 --INSERT INTO dbo.simoit00_Tischnummer(BedienungID)
 --VALUES
 --(2),(3),(1),(2),(1),(3),(2),(3),(1),(2),(3);

 --INSERT INTO dbo.simoit00_Bestellung(TischnummerID,ReisID,NudelnID)
 --VALUES
 --(2 ,2,3),
 --(2,1,4),
 --(1,2,3),
 --(3,5,5),
 --(4,2,4),
 --(5,3,1),
 --(5,2,1),
 --(6,4,2);

 
/*CREATE PROCEDURE dbo.Menu_simoit00
 AS
 select r.ReisID as 'Nummer', r.Bezeichnung,FORMAT(r.Preis, 'C', 'de-de'), n.NudelnID as 'Nummer', n.Bezeichnung, FORMAT(n.Preis, 'C', 'de-de')  
 from simoit00_Reisgericht r
 full outer join simoit00_Nudelgericht n
 on r.ReisID = n.NudelnID;
 return 0;*/
 

 CREATE TRIGGER ReisgerichtPreisänderung
 on dbo.simoit00_Reisgericht
 FOR UPDATE
 AS
 BEGIN
	select ReisID as 'Nummer',Bezeichnung,FORMAT(Preis, 'C', 'de-de') from simoit00_Reisgericht;
 END

 /*CREATE TRIGGER NudelgerichtPreisänderung
 on dbo.simoit00_Nudelgericht
 FOR UPDATE
 AS
 BEGIN
	select NudelnID as 'Nummer', Bezeichnung, FORMAT(Preis, 'C', 'de-de') from simoit00_Nudelgericht;
 END*/

 /*CREATE FUNCTION dbo.rechnungAnzeigen_simoit00 (@Tischnummer_simoit00 int)
 RETURNS TABLE
 AS RETURN
 (
	select b.BestellungID, t.TischnummerID as Tischnummer, r.Bezeichnung as Reisgericht, n.Bezeichnung as Nudelgericht, FORMAT(sum(r.Preis+ n.Preis), 'C', 'de-de')   as Gesamtpreis
	from simoit00_Bestellung as b
	inner join simoit00_Tischnummer as t
	on b.TischnummerID = t.TischnummerID
	inner join simoit00_Reisgericht as r
	on b.ReisID = r.ReisID
	inner join simoit00_Nudelgericht as n
	on b.NudelnID = n.NudelnID
	group by b.BestellungID, t.TischnummerID, r.Bezeichnung, n.Bezeichnung
	having t.TischnummerID = @Tischnummer_simoit00
 );*/


go

