Create Procedure ProduktInKarte @Kartenname varchar(50), @Produktname varchar(50)
As
Begin
	Declare @Kartenid int = 0
	Declare @Produktid int = 0
	Select @Kartenid =  KID from maskit_Karte Where Kname=@Kartenname
	Select @Produktid =  PID from maskit_Produkt Where Pname=@Produktname
	Insert into Produkt_in_Karte Values (dbo.Kartenname_zu_ID(@KartenName),dbo.Produktname_zu_ID(@ProduktName))
END
go

