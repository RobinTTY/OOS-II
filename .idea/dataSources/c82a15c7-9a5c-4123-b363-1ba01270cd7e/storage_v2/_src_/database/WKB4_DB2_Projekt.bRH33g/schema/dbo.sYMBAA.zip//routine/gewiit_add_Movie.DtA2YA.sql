CREATE PROCEDURE
[dbo].[gewiit_add_Movie]
	@MovieTitle	varchar(255),
	@MovieGenres varchar(255),
	@MovieLength int,
	@MovieReleaseDate varchar(255),
	@MainCharackter	varchar(255)
AS
--DECLARE @var1 float;
insert into WKB4_DB2_Projekt.dbo.gewiit_Movies
values(@MovieTitle,@MovieGenres,@MovieLength,@MovieReleaseDate,@MainCharackter);
print'Neuer Film Angelegt'
RETURN 0

/*EXEC dbo.gewiit_add_Movie_Short GolenEye,Action,130,1995,PierceBrosnn;*/
go

