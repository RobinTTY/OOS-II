CREATE PROCEDURE dbo.Broeker_addToPlaylist

@VNR int,
@TNR int,
@INR int,
@PNR int

AS
BEGIN 

	if @VNR IN(SELECT PNR FROM dbo.Broeker_Verwaltung)
	BEGIN print 'Eintrag mit der Nummer '+ @VNR + ' schon vorhanden'
	END
		
	else 
 
	DECLARE @TNAME varchar(255) = (SELECT TNAME FROM dbo.Broeker_Titel WHERE TNR = @TNR);
	DECLARE @PNAME varchar(255) = (SELECT PNAME FROM dbo.Broeker_Playlist WHERE PNR = @PNR);
	INSERT INTO dbo.Broeker_Verwaltung(VNR, TNR, INR, PNR)
	VALUES (@VNR, @TNR, @INR, @PNR);
	print 'Der Titel ' + @TNAME + ' wurde zur Playlist ' + @PNAME + ' hinzugefügt';

END
go

