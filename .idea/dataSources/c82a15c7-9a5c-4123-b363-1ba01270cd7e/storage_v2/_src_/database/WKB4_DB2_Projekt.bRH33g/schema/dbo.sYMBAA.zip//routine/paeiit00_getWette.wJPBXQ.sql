-- ================================================
-- Template generated from Template Explorer using:
-- Create Scalar Function (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- This block of comments will not be included in

CREATE FUNCTION [dbo].[paeiit00_getWette]
(
	-- Add the parameters for the function here
	@spn int,
	@wtor int,
	@username varchar(30)
)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @result int

	-- Add the T-SQL statements to compute the return value here

	IF(@wtor=1)
	select @result = wtor1 
	from paeiit00_wetten
	inner join paeiit00_person
	on paeiit00_person.pn = paeiit00_wetten.pn
	where username = @username
	AND spn = @spn

	ELSE
	select @result = wtor2 
	from paeiit00_wetten
	inner join paeiit00_person
	on paeiit00_person.pn = paeiit00_wetten.pn
	where username = @username
	AND spn = @spn

	-- Return the result of the function
	RETURN @result

END
go

