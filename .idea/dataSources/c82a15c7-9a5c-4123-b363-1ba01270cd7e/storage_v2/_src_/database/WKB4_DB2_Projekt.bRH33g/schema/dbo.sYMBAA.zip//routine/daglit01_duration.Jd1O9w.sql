CREATE FUNCTION daglit01_duration (@beginDate DATETIME, @endDate DATETIME)
RETURNS TIME
AS BEGIN
	RETURN @endDate - @beginDate
END
go

