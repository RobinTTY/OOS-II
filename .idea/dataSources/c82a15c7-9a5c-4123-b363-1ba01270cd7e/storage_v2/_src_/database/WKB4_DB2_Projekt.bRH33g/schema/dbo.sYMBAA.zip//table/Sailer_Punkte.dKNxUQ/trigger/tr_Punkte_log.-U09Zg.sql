CREATE TRIGGER tr_Punkte_log
ON Sailer_Punkte
AFTER DELETE
AS
BEGIN
	INSERT INTO Sailer_Punkte_log
	SELECT current_timestamp, host_name(), suser_name(), 'DELETE', mitspieler_id, spieltag_id, punkte, saison
	FROM deleted
END
go

