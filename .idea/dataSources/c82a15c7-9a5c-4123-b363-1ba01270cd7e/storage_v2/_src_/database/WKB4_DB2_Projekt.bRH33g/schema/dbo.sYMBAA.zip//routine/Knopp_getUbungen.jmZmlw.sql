CREATE PROCEDURE Knopp_getÜbungen
AS
select * from Knopp_tblÜbungen
GO;
go

