-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[functiondrohne] 
(
	@dronenname varchar(255)

)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @dronecount int

	-- Add the T-SQL statements to compute the return value here
	SELECT @dronecount = count(WettbewerbID)
	from vawait00_Teilnahme as t
	join vawait00_Drohnen as d
	on t.DrohnenID = d.DrohnenID
	where d.Name = @dronenname;
	IF (@dronecount IS NULL)   
        SET @dronecount = 0
 

	-- Return the result of the function
	RETURN @dronecount

END
go

