Create TRIGGER dbo.Trigger_Schoellkopf
ON dbo.Schoellkopf_Spieler
for INSERT
as 
BEGIN
set nocount on
Declare @spielerzahl INT;

Select @spielerzahl = count(spielerID) from dbo.Schoellkopf_Spieler;

	print 'Neuer Spieler angelegt. Es gibt jetzt insgesamt ' + cast(@spielerzahl as varchar) + ' Spieler';
END
go

