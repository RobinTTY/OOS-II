CREATE PROCEDURE sp_charit_bewertung
@title varchar(100),
@bewertung int,
@user varchar(8)
AS
	INSERT INTO charit_literatur_bewertung(litTitle, bewertung, IDUser)
	Values(@title, @bewertung, @user)
go

