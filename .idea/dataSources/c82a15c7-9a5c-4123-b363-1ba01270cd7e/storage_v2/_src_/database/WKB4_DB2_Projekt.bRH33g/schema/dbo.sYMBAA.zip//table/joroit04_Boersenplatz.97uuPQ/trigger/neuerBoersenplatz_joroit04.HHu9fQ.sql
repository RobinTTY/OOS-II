/*
CREATE TABLE dbo.joroit04_Aktie
(AktienID int IDENTITY PRIMARY KEY,
 Symbol varchar(255),
 Wert float ,
 AktiengesellschaftID int);
 
CREATE TABLE dbo.joroit04_Aktionaer
(AktionaerID int IDENTITY PRIMARY KEY,
 Nachname varchar(255),
 Vorname varchar(255));

CREATE TABLE dbo.joroit04_Boersenplatz
(BoersenplatzID int IDENTITY PRIMARY KEY,
 Bezeichnung varchar(255),
 Ort varchar(255));
 
CREATE TABLE dbo.joroit04_Aktiengesellschaft
(AktiengesellschaftID int IDENTITY PRIMARY KEY,
 Bezeichnung varchar(255),
 Hauptsitz varchar(255),
 Umsatz float); 
 
CREATE TABLE dbo.joroit04_Beteiligung
(BeteiligungID int IDENTITY PRIMARY KEY,
 AktionaerID int,
 AktienID int);

CREATE TABLE dbo.joroit04_GehandelteAktien
(HandlungsID int IDENTITY PRIMARY KEY,
 AktienID int,
 BoersenplatzID int,
 AktionaerID int);
 */
/*
ALTER TABLE dbo.joroit04_Aktie
ADD CONSTRAINT FK_Aktie --name des FK
FOREIGN KEY (AktiengesellschaftID) REFERENCES dbo.joroit04_Aktiengesellschaft (AktiengesellschaftID);
 */

/*
ALTER TABLE dbo.joroit04_Beteiligung
ADD CONSTRAINT FK_Beteiligung
FOREIGN KEY (AktienID) REFERENCES dbo.joroit04_Aktie (AktienID),
FOREIGN KEY (AktionaerID) REFERENCES dbo.joroit04_Aktionaer (AktionaerID);

ALTER TABLE dbo.joroit04_GehandelteAktien
ADD CONSTRAINT FK_Handlung
FOREIGN KEY (AktienID) REFERENCES dbo.joroit04_Aktie (AktienID),
FOREIGN KEY (AktionaerID) REFERENCES dbo.joroit04_Aktionaer (AktionaerID),
FOREIGN KEY (BoersenplatzID) REFERENCES dbo.joroit04_Boersenplatz (BoersenplatzID);
*/




/*
 INSERT INTO dbo.joroit04_Aktiengesellschaft(Bezeichnung, Hauptsitz, Umsatz)
 VALUES
 ('Amazon Inc.', 'Seattle', 136000000000),
 ('Daimler AG', 'Stuttgart', 153000000000),
 ('Blackrock Inc.', 'New York City', 11210000000),
 ('JPMorgan Chase & Co.', 'New York City', 95668000000),
 ('Microsoft Corporation', 'Redmond', 85320000000),
 ('Siemens AG','Muenchen',79644000000),
 ('BMW AG', 'Muenchen', 94160000000);
 *//*
 INSERT INTO dbo.joroit04_Aktie(Symbol, Wert, AktiengesellschaftID)
 VALUES
 ('AMZN', 1169.47, 1),
 ('DAI', 70.80, 2),
 ('BLQA', 513.71, 3),
 ('CMC', 106.94, 4),
 ('MSFT', 85.54, 5),
 ('SIE', 116.15, 6),
 ('BMW', 86.93, 7);
 
INSERT INTO dbo.joroit04_Aktionaer(Nachname,Vorname)
VALUES
 ('Mueller', 'Gerhard'),
 ('Rogers', 'Ryan'),
 ('Ruffet', 'Warren'),
 ('Shmiazu', 'Toriyama');

INSERT INTO dbo.joroit04_Boersenplatz(Bezeichnung,Ort)
VALUES
 ('NYSE', 'New York City'),
 ('Nasdaq', 'New York City'),
 ('XETRA', 'Frankfurt am Main');*/

 /*
INSERT INTO joroit04_Beteiligung(AktionaerID,AktienID)
VALUES
(1,1), 
(1,1), 
(1,1), 
(2,2), 
(2,7),
(3,5),
(3,6),
(4,3),
(4,3),
(4,4),
(4,4);
*/

/*
INSERT INTO joroit04_GehandelteAktien(AktienID,BoersenplatzID,AktionaerID)
VALUES
(3,1,4),
(4,1,4),
(6,3,3),
(5,2,3),
(1,2,1);
*/

/*select g.HandlungsID, akt.Symbol, akg.Bezeichnung as Aktiengesellschaft, brs.Bezeichnung as Boerse, brs.Ort
from joroit04_GehandelteAktien as g
inner join joroit04_Aktie as akt
on g.AktienID = akt.AktienID
inner join joroit04_Boersenplatz as brs
on g.BoersenplatzID = brs.BoersenplatzID
inner join joroit04_Aktiengesellschaft as akg
on akt.AktiengesellschaftID = akg.AktiengesellschaftID;*/


 --Stored Procedure
/*CREATE procedure dbo.gehandelteAktien_joroit04
AS
select g.HandlungsID, akt.Symbol, akg.Bezeichnung as Aktiengesellschaft, brs.Bezeichnung as Boerse, brs.Ort
from joroit04_GehandelteAktien as g
inner join joroit04_Aktie as akt
on g.AktienID = akt.AktienID
inner join joroit04_Boersenplatz as brs
on g.BoersenplatzID = brs.BoersenplatzID
inner join joroit04_Aktiengesellschaft as akg
on akt.AktiengesellschaftID = akg.AktiengesellschaftID
return 0;
*/


--Trigger
CREATE trigger neuerBoersenplatz_joroit04
on dbo.joroit04_Boersenplatz
FOR INSERT
AS
BEGIN
	SET NOCOUNT ON
	select * from joroit04_Boersenplatz;
END
go

