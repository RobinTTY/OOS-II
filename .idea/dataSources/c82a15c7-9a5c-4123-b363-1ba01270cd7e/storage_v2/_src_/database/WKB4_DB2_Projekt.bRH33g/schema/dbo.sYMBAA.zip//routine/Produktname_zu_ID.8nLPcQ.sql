Create function dbo.Produktname_zu_ID(@Produktname varchar(30))
Returns int
as  begin

	declare @produktid int;
	Select  @produktid = mk.PID from maskit_Produkt as mk Where Pname = @Produktname
	Return	@produktid

END
go

