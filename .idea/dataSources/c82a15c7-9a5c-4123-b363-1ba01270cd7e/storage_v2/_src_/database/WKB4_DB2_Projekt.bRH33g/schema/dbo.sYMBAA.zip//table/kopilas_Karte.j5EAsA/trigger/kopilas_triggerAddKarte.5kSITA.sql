CREATE TRIGGER kopilas_triggerAddKarte
ON dbo.kopilas_Karte
AFTER INSERT
AS 
BEGIN	
	INSERT INTO dbo.Kopilas_Karte_Log (id,anzahl) values
	(	(select max(kNR) from kopilas_karte),
		(select sum(kopien) from kopilas_Karte)
	)
END
go

