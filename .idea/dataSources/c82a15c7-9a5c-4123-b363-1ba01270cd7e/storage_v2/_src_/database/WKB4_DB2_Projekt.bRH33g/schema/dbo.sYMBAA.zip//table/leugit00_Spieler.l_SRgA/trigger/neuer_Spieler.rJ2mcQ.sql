create trigger neuer_Spieler
on leugit00_Spieler
after insert as
begin
insert into leugit00_Tore
select Vorname,null,null, null, null,null,null,null
 from inserted
end
go

