create Trigger trigger_Schlappa1
on dbo.Schlappa_Einnahmen
for insert
as
begin
declare @summeBetrag float;
declare @anzahlTransaktionen int;

select @summeBetrag = sum(Betrag) from dbo.Schlappa_Einnahmen
select @anzahlTransaktionen = count(EID) from dbo.Schlappa_Einnahmen

print 'Es wurden ' +cast(@summeBetrag as varchar)+ ' Euro ausgegeben und dabei' +cast(@anzahlTransaktionen as varchar)+ ' Transaktionen durchgeführt!'
end
go

