create function Schlappa_anzahlTransaktionen
()
returns int
as
begin
declare @anzahl int
select @anzahl = sum(TAID)
from dbo.Schlappa_Ausgaben
return @anzahl
end;
go

