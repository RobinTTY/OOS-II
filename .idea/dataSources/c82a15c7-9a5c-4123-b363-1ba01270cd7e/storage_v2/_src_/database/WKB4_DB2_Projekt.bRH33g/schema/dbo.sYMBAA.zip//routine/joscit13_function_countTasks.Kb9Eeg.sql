CREATE FUNCTION dbo.joscit13_function_countTasks (@category int)
RETURNS int
AS
BEGIN
	RETURN (SELECT COUNT(*) FROM dbo.joscit13_task WHERE category=@category);
END;
go

