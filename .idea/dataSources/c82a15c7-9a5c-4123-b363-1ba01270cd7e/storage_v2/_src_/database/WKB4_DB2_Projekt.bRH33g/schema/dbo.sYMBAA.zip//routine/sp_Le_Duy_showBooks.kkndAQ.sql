CREATE PROCEDURE sp_Le_Duy_showBooks
AS
BEGIN
	SELECT DISTINCT b.BuchID, b.Buchtitel,b.ISBN ,b.Anzahl
	FROM Le_Duy_Buch b
	JOIN Le_Duy_Autor_Buch ab ON b.BuchID = ab.BuchID
	JOIN Le_Duy_Autor a ON ab.AutorID = a.AutorID
END
go

