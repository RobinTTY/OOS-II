create procedure
dbo.Zink_Gesamtausgaben
as
select sum(menge) from zink_ausgaben
go

