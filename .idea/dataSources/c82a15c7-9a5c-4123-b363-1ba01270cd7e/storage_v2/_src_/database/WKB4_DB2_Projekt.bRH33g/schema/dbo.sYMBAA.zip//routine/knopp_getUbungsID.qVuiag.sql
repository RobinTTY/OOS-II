CREATE PROCEDURE knopp_getÜbungsID
@übungID int,
@Übung varchar(30) = null
AS
insert into knopp_tblübungen (IDÜbungen, übungen)
values (@übungID,@Übung)
return 0
go

