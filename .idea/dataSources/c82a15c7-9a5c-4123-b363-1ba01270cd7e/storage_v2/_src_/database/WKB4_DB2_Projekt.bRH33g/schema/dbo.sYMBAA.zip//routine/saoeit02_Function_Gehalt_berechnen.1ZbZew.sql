CREATE Function dbo.saoeit02_Function_Gehalt_berechnen
(
	@parm1 float, 
	@parm2 float
)
returns float
as 
begin 
declare @ergebnis float;
	begin 
	    select @ergebnis=@parm1 * @parm2
		select @ergebnis=@ergebnis*100
		select @ergebnis=ROUND(@ergebnis,1)
		select @ergebnis=@ergebnis/100
	end
	return @ergebnis
end
go

