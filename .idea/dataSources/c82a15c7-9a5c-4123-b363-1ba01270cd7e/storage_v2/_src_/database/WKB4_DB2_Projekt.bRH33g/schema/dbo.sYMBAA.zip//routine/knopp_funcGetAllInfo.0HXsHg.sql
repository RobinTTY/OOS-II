Create FUNCTION knopp_funcGetAllInfo
(
)
RETURNS TABLE
AS
RETURN (select distinct(idinfo),übungen,gewicht,wiederholungen,datum from Knopp_tblInfo
join Knopp_tblÜbungen on Knopp_tblInfo.IDÜbungen = Knopp_tblÜbungen.IDÜbungen
join Knopp_tblDatum on Knopp_tblInfo.IDDatum = Knopp_tblDatum.IDDatum
)
go

