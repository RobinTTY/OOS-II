CREATE PROCEDURE dbo.Broeker_addInterpret
@NR int,
@NAME varchar(255)

AS
BEGIN 
	if @NR IN(SELECT INR FROM dbo.Broeker_Interpret)
	BEGIN print 'Nummer schon vorhanden'
	END
		
	else 
	BEGIN
	INSERT INTO dbo.Broeker_Interpret (INR, INAME)
	VALUES (@NR, @NAME);
	print 'Interpret mit der Nummer ' + cast (@NR as varchar(10)) + ' und dem Namen ' + @Name + ' wurde angelegt';
	END
END
go

