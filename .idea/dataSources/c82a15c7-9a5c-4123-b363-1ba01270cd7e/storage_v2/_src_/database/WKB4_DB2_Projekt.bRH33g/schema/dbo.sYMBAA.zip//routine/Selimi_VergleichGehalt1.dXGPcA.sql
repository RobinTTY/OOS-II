
 /*
create PROCEDURE Selimi_Mitarbeiter_Select @Nummer int
AS

begin
SELECT name 
FROM Selimi_Mitarbeiter 
WHERE PersNr = @Nummer

return Name
END
*/
---exec Selimi_Mitarbeiter_Select @Nummer = 1



create FUNCTION Selimi_VergleichGehalt1
(
	@input1 int,
	@input2 int
)
returns int
AS 
Begin
	declare @ergebnis int = null
	if @input1 > @input2
		Begin
			Set @ergebnis = (Select PersNr from Selimi_Mitarbeiter where PersNr=@input1)
		End
	else
		Begin
			Set @ergebnis = (Select PersNr from Selimi_Mitarbeiter where PersNr=@input2)
		End
	return @ergebnis
End

--SELECT [dbo].[Selimi_VergleichGehalt] (80000,6000)


 go

