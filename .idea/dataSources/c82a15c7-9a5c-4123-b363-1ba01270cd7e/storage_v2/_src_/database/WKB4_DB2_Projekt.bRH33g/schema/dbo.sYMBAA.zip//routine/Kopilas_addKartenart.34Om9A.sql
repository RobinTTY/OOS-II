CREATE PROCEDURE dbo.Kopilas_addKartenart
@artNR int OUT,
@art varchar(50) OUT
AS 
BEGIN
	INSERT INTO [kopilas_KarteArt] (ArtNR, Art)
	VALUES (@artNR, @art)
END
go

