CREATE PROCEDURE knopp_getÜbungID
AS
select idübungen from Knopp_tblÜbungen
GO;
go

