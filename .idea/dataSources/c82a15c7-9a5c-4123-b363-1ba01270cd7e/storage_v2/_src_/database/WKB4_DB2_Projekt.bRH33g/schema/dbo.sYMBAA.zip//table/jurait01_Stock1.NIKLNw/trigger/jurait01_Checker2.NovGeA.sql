CREATE TRIGGER jurait01_Checker2
   ON  jurait01_Stock1 
   AFTER UPDATE
AS 
BEGIN

	if ((SELECT Stock From Inserted) > ((SELECT Max From Inserted)/2))
	Begin
		Delete jurait01_Einkaufszettel where (Select Artikel From Inserted) = (Select NR From jurait01_Artikel Where NR = (Select Artikel From Inserted))
	End

END
go

