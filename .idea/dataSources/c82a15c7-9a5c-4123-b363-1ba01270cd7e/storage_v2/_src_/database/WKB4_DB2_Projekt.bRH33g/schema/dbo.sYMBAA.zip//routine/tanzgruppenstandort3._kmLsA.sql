create procedure [dbo].[tanzgruppenstandort3]
@StandortID varchar(50)
as
select Tanzgruppenname
from emayit01_Tanzgruppe
Where StandortID = @StandortID;


go

