CREATE PROCEDURE [dbo].[villalilla_overview]
AS
	SELECT * FROM [dbo].[villalilla_keys];
	SELECT * FROM [dbo].[villalilla_games];
	SELECT * FROM [dbo].[villalilla_bundles];
RETURN 0
go

