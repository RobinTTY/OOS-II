Create Function dbo.Arnold_Bestellpreis
( 
@artikel int,
@anzahl int
)
returns float
as
begin 
declare @ergebnis float;
select @ergebnis=preis_je_stk *@anzahl
from Arnold_Schokolade
where Artikelnr=@artikel
 return @ergebnis
end
go

