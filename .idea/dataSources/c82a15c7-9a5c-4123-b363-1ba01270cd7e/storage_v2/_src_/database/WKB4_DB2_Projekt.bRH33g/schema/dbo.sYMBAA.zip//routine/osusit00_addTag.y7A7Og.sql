CREATE Procedure dbo.osusit00_addTag
	@Artist varchar(255),
	@Title varchar(255),
	@Album varchar(255),
	@Years int
AS
	INSERT INTO WKB4_DB2_Projekt.dbo.osusit00_mp3Tags VALUES (@Artist, @Title, @Album, @Years);
	PRINT 'Tag wurde hinzugefuegt.'
RETURN 0

--EXEC dbo.osusit00_addTag 'TestArt', 'Test', 'TestAlb', 2015;
go

