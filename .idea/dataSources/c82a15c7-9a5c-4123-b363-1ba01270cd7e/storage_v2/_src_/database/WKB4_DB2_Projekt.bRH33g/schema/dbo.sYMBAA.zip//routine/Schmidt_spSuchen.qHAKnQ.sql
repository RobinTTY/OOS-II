CREATE procedure dbo.Schmidt_spSuchen
(@suchwort nvarchar(50))

as
begin

declare @count int=0;
declare @Schmidt_Suchergebnisse table(
		 BNr INT NULL,
		 Autor VARCHAR(50) NULL,
		 Titel VARCHAR(100) NULL,
		 Verlag VARCHAR(50) NULL,
		 Anzahl INT NULL);

	set @count=(select count(*) from Schmidt_Buch where Titel like '%'+@suchwort+'%')

	IF (@count >0)
		begin
		 
		 insert into @Schmidt_Suchergebnisse (BNr, Autor, Titel, Verlag, Anzahl)
		 select BNr, Autor, Titel, Verlag, Anzahl from Schmidt_Buch 
		 where Titel like '%'+@suchwort+'%' 
		 select * from @Schmidt_Suchergebnisse
		end	 
	ELSE 
		 print 'Kein Buch vorhanden.'

end
go

