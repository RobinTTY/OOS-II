CREATE PROCEDURE dbo.Broeker_addTitel
@NR int,
@NAME varchar(255),
@INR int,
@GENRE varchar(255),
@LAENGE int

AS
BEGIN 
	if @NR IN(SELECT TNR FROM dbo.Broeker_Titel)
	BEGIN print 'Nummer schon vorhanden'
	END
		
	else 
	BEGIN
	INSERT INTO dbo.Broeker_Titel(TNR, TNAME, INR, GENRE, LAENGE)
	VALUES (@NR, @NAME, @INR, @GENRE, @LAENGE);
	print 'Titel mit der Nummer ' + cast (@NR as varchar(10)) + ' und dem Namen ' + @Name + ' wurde angelegt';
	END
END
go

