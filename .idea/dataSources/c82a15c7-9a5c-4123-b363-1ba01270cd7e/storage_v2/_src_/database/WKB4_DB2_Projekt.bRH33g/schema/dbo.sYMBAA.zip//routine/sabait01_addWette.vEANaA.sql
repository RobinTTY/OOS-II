
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE dbo.sabait01_addWette 
	-- Add the parameters for the stored procedure here
	@wettId int,
	@spielerId int,
	@spielId int,
	@toreTeam int,
	@toreGegner int

AS
INSERT INTO dbo.sabait01_wette VALUES (@wettId, @spielerId, @spielId, @toreTeam, @toreGegner);
go

