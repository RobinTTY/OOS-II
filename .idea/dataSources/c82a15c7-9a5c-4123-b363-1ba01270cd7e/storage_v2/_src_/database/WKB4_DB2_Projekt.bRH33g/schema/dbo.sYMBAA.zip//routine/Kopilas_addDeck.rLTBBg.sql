CREATE PROCEDURE dbo.Kopilas_addDeck 
@decknummer int OUT ,
@name varchar(50) OUT
AS 
BEGIN
	INSERT INTO [kopilas_Deck] (DNR , dname)
	VALUES (@decknummer, @name)
END
go

