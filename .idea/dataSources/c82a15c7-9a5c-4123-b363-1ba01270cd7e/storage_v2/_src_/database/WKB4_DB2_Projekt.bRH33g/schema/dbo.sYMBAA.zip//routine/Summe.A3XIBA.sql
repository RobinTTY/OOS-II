CREATE function [dbo].[Summe]
(
	 @summe int = 0
)

returns int
as
begin	
	select @summe = (select SUM(Betrag) from AuftragSet where Status = 'wird bearbeitet')
	return @summe
	

end
go

