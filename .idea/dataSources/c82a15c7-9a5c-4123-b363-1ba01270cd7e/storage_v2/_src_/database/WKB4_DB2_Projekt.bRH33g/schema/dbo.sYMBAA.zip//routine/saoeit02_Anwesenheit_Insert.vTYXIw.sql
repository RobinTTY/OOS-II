CREATE PROCEDURE [dbo].[saoeit02_Anwesenheit_Insert]
@A_ID int ,
@Mit_id int,
@anwesenheit float

AS

 
BEGIN 
	if @Mit_id IN(SELECT MitarbeiterID FROM dbo.saoeit02_Mitarbeiter)
	BEGIN 
	Insert into saoeit02_Anwesenheit(A_id,Mit_ID,Datum,Anwesenheit)
	Values(@A_ID,@Mit_id,GETDATE(),@anwesenheit);
	END
	
	else 
	BEGIN
	print 'Mitarbeiter ID ist nicht vorhanden, bitte versuchen sie es erneut'
	END
	
End
go

