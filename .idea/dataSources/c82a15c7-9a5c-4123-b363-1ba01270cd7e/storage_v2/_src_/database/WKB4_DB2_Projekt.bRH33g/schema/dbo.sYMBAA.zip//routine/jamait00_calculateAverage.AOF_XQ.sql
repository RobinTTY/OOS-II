CREATE FUNCTION [dbo].[jamait00_calculateAverage]
(
@choice varchar(18)
)
RETURNS DECIMAL(7,2)
AS
BEGIN
	DECLARE @average DECIMAL(7,2)
	IF(@choice = 'NO3') 
		BEGIN
		SELECT @average = AVG(No3)
		FROM jamait00_durchfluss
		WHERE No3 != 0
		END
	ELSE IF(@choice = 'Durchfluss')
		BEGIN
		SELECT @average = AVG(Durchfl_l_sec)
		FROM jamait00_durchfluss
		WHERE Durchfl_l_sec != 0
		END
	ELSE IF(@choice = 'Durchfluss Nivus')
		BEGIN
		SELECT @average = AVG(DurchflNiv_l_sec)
		FROM jamait00_durchfluss
		WHERE DurchflNiv_l_sec != 0
		END
	ELSE IF(@choice = 'Differenz relativ')
		BEGIN
		SELECT @average = AVG(Diff_proz)
		FROM jamait00_durchfluss
		WHERE DurchflNiv_l_sec != 0
		END
	RETURN @average;
END;
go

