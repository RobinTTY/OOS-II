CREATE PROCEDURE dbo.almait06_LadenReader
@LadenID int = null,
@Ladenname varchar(100) = null,
@Strasse varchar(100) = null,
@Strassennummer int = null,
@Ort varchar(50) = null,
@Plz int = null
AS
BEGIN
	SELECT * FROM dbo.almait06_Laden 
	WHERE (LadenID = @LadenID OR @LadenID IS NULL)
	AND (Ladenname = @Ladenname OR @Ladenname IS NULL)
	AND (Strasse = @Strasse OR @Strasse IS NULL)
	AND (Strassennummer = @Strassennummer OR @Strassennummer IS NULL)
	AND (Ort = @Ort OR @Ort IS NULL)
	AND (Plz = @Plz OR @Plz IS NULL)
END
go

