
 /*
create PROCEDURE Selimi_Mitarbeiter_Select @Nummer int
AS

begin
SELECT name 
FROM Selimi_Mitarbeiter 
WHERE PersNr = @Nummer

return Name
END
*/
---exec Selimi_Mitarbeiter_Select @Nummer = 1



create FUNCTION Selimi_SummeGehaltAlle
(
	
)
returns int
AS 
Begin
	DECLARE @ret int;
	SELECT @ret = Sum(gehalt)
	FROM Selimi_Mitarbeiter m
	Join Selimi_Gehalt g on m.Gehalt_id=g.id

	return @ret
End

--SELECT [dbo].[Selimi_SummeGehaltAlle] 


 go

