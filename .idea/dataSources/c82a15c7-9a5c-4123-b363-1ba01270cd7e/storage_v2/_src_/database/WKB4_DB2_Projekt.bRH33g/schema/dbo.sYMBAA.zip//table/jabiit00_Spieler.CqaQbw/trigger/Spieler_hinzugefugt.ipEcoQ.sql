CREATE TRIGGER [dbo].[Spieler_hinzugefügt]
ON [dbo].[jabiit00_Spieler]
FOR INSERT
AS
BEGIN
	DECLARE @anzahl int;
	Select @anzahl = count(*) From dbo.jabiit00_Spieler;
	print 'Die Anzahl der Spieler bei der EM beträgt: ' + CAST(@anzahl AS varchar);
END
go

