

--- c ---
CREATE VIEW Nettoview 
AS
SELECT SUM(m.Stundensatz * po.Stundenanzahl) AS Nettoumsatz
FROM dbo.nisiit00_Mitarbeiter AS m
JOIN dbo.nisiit00_Position AS po
ON m.MNr = po.MNr
go

