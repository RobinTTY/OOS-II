
CREATE TRIGGER [dbo].[MovieTrigger_Short]
ON [dbo].[gewiit_Movies_Short]
FOR INSERT
AS
BEGIN
SET NOCOUNT ON
Declare @Anzahl int
Declare @var1 varchar(255)
Select @Anzahl =count(*) from dbo.gewiit_Movies_Short;
Select @var1 = dbo.gewiit_MovieFunction_Short();
print'Anzahl der Filme: '+cast (@Anzahl as varchar)
print 'Alle Filme zusammen in der DB haben die Länge von: '+@var1+'min'
--insert code here
END
go

