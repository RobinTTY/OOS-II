--Stored Procedure

CREATE procedure 
dbo.sekait04_Stuttgart
AS
BEGIN
select count(*) as AnzahlMitgliederAusStuttgart
from sekait04_Mitglieder 
where Ort='Stuttgart';
END
go

