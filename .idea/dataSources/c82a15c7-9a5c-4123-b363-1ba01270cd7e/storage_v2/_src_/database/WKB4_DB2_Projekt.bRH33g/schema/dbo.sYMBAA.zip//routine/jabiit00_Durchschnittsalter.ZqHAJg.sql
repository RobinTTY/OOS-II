CREATE FUNCTION [dbo].[jabiit00_Durchschnittsalter] ( @vereinsid int )
RETURNS float
AS
	BEGIN
		DECLARE @Durchschnittsalter float
		Select @Durchschnittsalter = (avg(DATEDIFF(YYYY, Geburtstag, getDate()))) 
		FROM dbo.jabiit00_Spieler 
		WHERE vereinsid = @vereinsid; 
		RETURN @Durchschnittsalter
	END
go

