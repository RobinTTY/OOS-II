create Trigger [dbo].[mai_log_verein]
on [dbo].[mai_Verein]
for Delete
as
begin

insert into [WKB4_DB2_Projekt].[dbo].[mai_log]
select CURRENT_TIMESTAMP, HOST_NAME(), SUSER_NAME(), 'DELETE','Verein'
from deleted

end
go

