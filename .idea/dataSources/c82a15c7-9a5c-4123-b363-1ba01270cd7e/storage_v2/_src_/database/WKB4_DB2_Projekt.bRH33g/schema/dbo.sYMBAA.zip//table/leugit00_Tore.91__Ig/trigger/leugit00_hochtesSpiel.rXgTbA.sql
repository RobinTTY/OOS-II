create trigger dbo.leugit00_höchtesSpiel
on dbo.leugit00_Tore
for insert
as
begin
set nocount on
declare @Summe int;

select @Summe=count(Hohenacker) from leugit00_Tore;
Print 'Beim Spiel gegen Hohenacker sind ' +cast(@summe as varchar)+ 'Tore gefallen.';
end
go

