CREATE Procedure [dbo].[sp_charit_searchitems]
@kategorie varchar(100),
@title varchar(100)
AS
	Select Distinct l.title, l.katName, l.bewertung
	From charit_literatur l
	Where l.title =@title OR l.katName = @kategorie
go

