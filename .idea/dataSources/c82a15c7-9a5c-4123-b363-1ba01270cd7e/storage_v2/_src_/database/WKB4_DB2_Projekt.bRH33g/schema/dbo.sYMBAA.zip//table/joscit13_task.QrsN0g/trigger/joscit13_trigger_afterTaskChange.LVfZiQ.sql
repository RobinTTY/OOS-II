CREATE TRIGGER dbo.joscit13_trigger_afterTaskChange
ON dbo.joscit13_task
AFTER INSERT, UPDATE, DELETE
AS
	EXEC dbo.joscit13_procedure_updateTaskCount;
go

