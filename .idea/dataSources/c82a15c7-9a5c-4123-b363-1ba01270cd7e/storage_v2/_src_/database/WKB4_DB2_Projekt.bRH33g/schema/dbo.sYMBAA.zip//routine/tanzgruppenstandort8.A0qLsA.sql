create procedure [dbo].[tanzgruppenstandort8]
as
select tg.Tanzgruppenname
from emayit01_Tanzgruppe tg
join emayit01_Standort st on tg.StandortID = st.StandortID
Where st.Standort = 'Esslingen';


go

