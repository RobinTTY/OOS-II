CREATE PROCEDURE dbo.Kopilas_addKarte
@kartennummer int OUT,
@kartenname varchar(50) OUT,
@artNr int,
@decknummer int OUT,
@copies int OUT,
@wert float


AS 
BEGIN
	INSERT INTO [kopilas_Karte] (knr, KartenName ,ArtNR, DeckNR, kopien, wert)
	VALUES (@kartennummer, @kartenname,@artNr, @decknummer, @copies,@wert)
END
go

