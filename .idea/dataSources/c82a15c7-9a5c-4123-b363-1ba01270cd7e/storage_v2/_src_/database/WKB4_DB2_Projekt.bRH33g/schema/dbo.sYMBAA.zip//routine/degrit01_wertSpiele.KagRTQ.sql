create function degrit01_wertSpiele
()
returns float
as
begin
declare @wert float
select @wert=sum(Preis)
from dbo.degrit01_PS4Spiele
return @wert

end;
go

