CREATE PROCEDURE 
dbo.maglit03_getGradesForStudent
	@MATR int
AS
	SELECT SUB, GRADE FROM dbo.maglit03_GRADE WHERE MATR = @MATR;
RETURN 0;

go

