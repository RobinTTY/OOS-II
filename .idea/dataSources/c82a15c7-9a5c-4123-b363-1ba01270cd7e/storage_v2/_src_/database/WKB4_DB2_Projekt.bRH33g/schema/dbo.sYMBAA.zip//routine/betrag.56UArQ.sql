CREATE FUNCTION dbo.betrag
(@a float,@b float)

RETURNS float
AS

BEGIN
  declare @ergebnis float;

  if @a > @b
  select @ergebnis = @a-@b
  else
  select @ergebnis = @b-@a

 RETURN @ergebnis

END
go

