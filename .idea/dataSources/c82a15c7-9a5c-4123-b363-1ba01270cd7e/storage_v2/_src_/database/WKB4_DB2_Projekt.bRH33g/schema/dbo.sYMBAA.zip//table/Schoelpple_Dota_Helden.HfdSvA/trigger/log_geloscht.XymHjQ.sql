CREATE TRIGGER [dbo].[log_gelöscht]
ON [WKB4_DB2_Projekt].[dbo].[schoelpple_Dota_Helden]
FOR DELETE

AS
BEGIN
SET NOCOUNT ON;
INSERT INTO [WKB4_DB2_Projekt].[dbo].[schoelpple_log_geloescht]
SELECT CURRENT_TIMESTAMP, SUSER_NAME(), Helden_Name
FROM deleted
END


go

