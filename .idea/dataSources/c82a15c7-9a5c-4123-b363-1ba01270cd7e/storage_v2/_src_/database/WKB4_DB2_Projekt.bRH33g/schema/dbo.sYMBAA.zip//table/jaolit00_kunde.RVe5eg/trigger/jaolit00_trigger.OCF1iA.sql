create trigger jaolit00_trigger
on dbo.jaolit00_kunde
for insert
as
begin

declare @anzahlKunden int;


select @anzahlKunden= count(Name) from dbo.jaolit00_kunde
   print 'Es gibt' +cast(@anzahlKunden as varchar)+ 'Kunden im Shop.'
end
go

