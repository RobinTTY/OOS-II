CREATE function dbo.Schmidt_fPrufAddBuch
(@Autor VARCHAR(50), @Titel VARCHAR(100))

returns int

as 
begin
	declare @pruf as int

	select @pruf = (select count(*)
	                from Schmidt_Buch 
					where @Autor= Autor and @Titel=Titel)
	return @pruf
end
go

