Create Trigger dbo.Remove_Match_Trigger
On dbo.Ilkov_Matches
AFTER DELETE  
AS
BEGIN
    INSERT INTO dbo.Ilkov_MatchHistory
		(
			HomeTeam,
			AwayTeam,
			ScoreHomeTeam,
			ScoreAwayTeam
		)


	SELECT 

			HomeTeam,
			AwayTeam,
			ScoreHomeTeam,
			ScoreAwayTeam

	 FROM deleted;

END
go

