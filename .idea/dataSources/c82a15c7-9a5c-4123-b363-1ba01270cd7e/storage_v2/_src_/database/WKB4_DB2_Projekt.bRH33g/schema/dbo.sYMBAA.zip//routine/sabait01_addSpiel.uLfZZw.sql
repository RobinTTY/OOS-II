
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sabait01_addSpiel] 
	-- Add the parameters for the stored procedure here
	@spielId int,
	@teamName nchar(30),
	@gegnerName nchar(30)

AS
INSERT INTO dbo.sabait01_spiel VALUES (@spielId, @teamName, @gegnerName, NULL, NULL);
go

