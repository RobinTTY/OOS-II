CREATE FUNCTION Erdenebileg_Prozent  (@rabatt int)
RETURNS varchar(5)
BEGIN

RETURN CAST(@rabatt AS varchar(3) )+ ' %'
END
go

