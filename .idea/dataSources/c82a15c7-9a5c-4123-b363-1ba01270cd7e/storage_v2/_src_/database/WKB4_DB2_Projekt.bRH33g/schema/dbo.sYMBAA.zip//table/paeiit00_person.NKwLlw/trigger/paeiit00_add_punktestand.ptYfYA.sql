
CREATE TRIGGER dbo.paeiit00_add_punktestand ON dbo.paeiit00_person
	AFTER INSERT 

AS 
DECLARE @pn int

SELECT @pn = pn from inserted 

Insert Into dbo.paeiit00_position
values(@pn, default)
go

