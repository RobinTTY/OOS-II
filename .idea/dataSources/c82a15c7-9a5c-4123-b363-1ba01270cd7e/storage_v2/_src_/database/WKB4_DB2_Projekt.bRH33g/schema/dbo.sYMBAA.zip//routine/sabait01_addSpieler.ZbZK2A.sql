
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE dbo.sabait01_addSpieler 
	-- Add the parameters for the stored procedure here
	@spielerId int,
	@nachname nchar(30),
	@vorname nchar(30)

AS
INSERT INTO dbo.sabait01_spieler VALUES (@spielerId, @nachname, @vorname, 0);
go

