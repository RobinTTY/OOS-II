create trigger dbo.dpm_delete_trigger
on dbo.dpm_patient
after delete as
begin

set nocount on

insert into dbo.dpm_log 
	(tk_log_timestamp,tk_log_hostname,tk_log_s_username,tk_log_action,tk_log_tablename,tk_log_c1,tk_log_c2,tk_log_c3,tk_log_c4,tk_log_c5,tk_log_c6,tk_log_c7,tk_log_c8)
values (CURRENT_TIMESTAMP, HOST_NAME(), SUSER_NAME(), 'Löschen' ,'Patient',
	(select p_id from deleted),
	(select p_name from deleted),
	(select p_vorname from deleted),
	(select p_krankenkasse from deleted),
	(select p_telefonnr from deleted),
	(select p_strasse from deleted),
	(select p_ort from deleted),
	(select p_birthday from deleted)
	)
end
go

