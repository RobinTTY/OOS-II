CREATE PROCEDURE dbo.almait06_BestandReader
@ArtikelID int = null,
@Artikelname varchar(100) = null,
@Menge int = null,
@Kaufdatum datetime = null
AS
BEGIN
	SELECT * FROM dbo.almait06_Bestand
	WHERE (ArtikelID = @ArtikelID OR @ArtikelID IS NULL)
	AND (Artikelname = @Artikelname OR @Artikelname IS NULL)
	AND (Menge = @Menge OR @Menge IS NULL)
	AND (Kaufdatum = @Kaufdatum OR @Kaufdatum IS NULL)
END
go

