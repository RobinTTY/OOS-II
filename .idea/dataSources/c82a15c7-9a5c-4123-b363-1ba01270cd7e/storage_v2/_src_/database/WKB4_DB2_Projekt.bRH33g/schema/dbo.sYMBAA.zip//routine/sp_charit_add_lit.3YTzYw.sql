CREATE procedure [dbo].[sp_charit_add_lit]
@kategorie varchar(50),
@title varchar(200),
@autor varchar(200),
@ISBN varchar(50),
@link varchar(200),
@bewertung int,
@userName varchar(8)
AS
INSERT INTO charit_literatur(title, autor, isbn, link, katName)
Values(@title, @autor, @ISBN, @link, @kategorie)
INSERT INTO charit_literatur_bewertung(litTitle, bewertung, IDUser)
Values(@title, @bewertung, @userName)
go

