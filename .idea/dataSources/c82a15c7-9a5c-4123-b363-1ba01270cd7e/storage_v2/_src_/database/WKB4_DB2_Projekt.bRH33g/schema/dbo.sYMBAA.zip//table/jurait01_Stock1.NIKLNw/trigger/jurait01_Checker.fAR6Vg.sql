CREATE TRIGGER [dbo].[jurait01_Checker]
   ON  [dbo].[jurait01_Stock1] 
   AFTER UPDATE
AS 
BEGIN

	if ((SELECT Stock From Inserted) < ((SELECT Max From Inserted)/2))
	Begin
		Declare @name as varchar(20)
		Declare @einheit as varchar(20)
		Declare @amount as nchar(10)
		set @name = (SELECT jurait01_Artikel.Name From jurait01_Artikel Where NR = (Select Artikel From Inserted))
		set @einheit = (SELECT Einheit From jurait01_Artikel Where NR = (Select Artikel From Inserted))
		set @amount = ((SELECT Max From Inserted)-(SELECT Stock From Inserted))
		Insert Into jurait01_Einkaufszettel (NR,Laden,Artikel,Amount,Einheit)
		Values(
			NEWID(),
			'Aldi',
			@name,
			@amount,
			@einheit)
	End

END
go

