CREATE PROCEDURE
[dbo].[jamait00_procFilternull]
AS
BEGIN
	select * from WKB4_DB2_Projekt.dbo.jamait00_durchfluss 
	WHERE No3 != 0
END	
	RETURN 0
go

