create procedure
dbo.Schlappa_AusgabenPruefen

AS
BEGIN


Select a.Transaktion_Ausgabe
FROM dbo.Schlappa_Ausgaben a
Where a.Betrag > 500.00
Order by a.Betrag desc
end
go

