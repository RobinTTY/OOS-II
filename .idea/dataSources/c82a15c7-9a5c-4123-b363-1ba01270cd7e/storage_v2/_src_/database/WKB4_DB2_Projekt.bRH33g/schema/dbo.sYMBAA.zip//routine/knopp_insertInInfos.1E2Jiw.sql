--select max(IDinfo) from Knopp_tblInfo
--delete from Knopp_tblInfo
--insert into Knopp_tblInfo (IDinfo)
--values(3)
--select * from Knopp_tblInfo

CREATE PROCEDURE knopp_insertInInfos 
@InfoID int, 
@ÜbungID int,
@IDDatum int,
@Gewicht float,
@Wiederholungen int
AS
insert into Knopp_tblInfo (IDInfo,IDÜbungen,IDDatum,Gewicht,Wiederholungen)
values (@InfoID,@ÜbungID,@IDDatum,@Gewicht,@Wiederholungen)
go

