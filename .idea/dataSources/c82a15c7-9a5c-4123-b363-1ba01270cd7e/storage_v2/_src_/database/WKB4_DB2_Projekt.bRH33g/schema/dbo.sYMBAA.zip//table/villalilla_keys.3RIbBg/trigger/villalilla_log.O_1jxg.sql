CREATE TRIGGER villalilla_log
ON [dbo].[villalilla_keys]
FOR DELETE
AS
BEGIN
	DECLARE @keyid int, @bundleid int, @gameid int, @gamekey varchar(30), @preis float;

	SELECT @keyid=d.keyId, @bundleid=d.bundleId, @gameid=d.gameId, @gamekey=d.gameKey, @preis=d.price
	FROM DELETED d;
	
	INSERT INTO [dbo].[villalilla_keys_dellog]
	VALUES(CURRENT_TIMESTAMP, @keyid, @bundleid, @gameid, @gamekey, @preis); 
END
go

