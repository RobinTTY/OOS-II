-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[schoelpple_functionhero] 
(
	@herorolle varchar(255)

)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @herocount int

	-- Add the T-SQL statements to compute the return value here
	SELECT @herocount = count(Rolle)
	from Schoelpple_Helden as h
	where Rolle = @herorolle;
	IF (@herocount IS NULL)   
        SET @herocount = 0
 

	-- Return the result of the function
	RETURN @herocount

END


go

