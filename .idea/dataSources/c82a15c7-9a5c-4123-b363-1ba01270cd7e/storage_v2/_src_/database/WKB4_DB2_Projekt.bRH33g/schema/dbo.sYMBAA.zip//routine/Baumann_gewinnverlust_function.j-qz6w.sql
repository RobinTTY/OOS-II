Create Function dbo.Baumann_gewinnverlust_function 	 (
@param1 float,
@param2 float)	
returns float
as
begin 
	declare @ergebnis float;
	select @ergebnis = @param1 - @param2
	return @ergebnis;
end
go

