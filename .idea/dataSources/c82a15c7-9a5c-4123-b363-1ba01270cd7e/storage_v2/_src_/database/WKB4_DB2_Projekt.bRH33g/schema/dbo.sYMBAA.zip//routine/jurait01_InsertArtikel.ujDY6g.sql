
CREATE PROCEDURE jurait01_InsertArtikel
	-- Add the parameters for the stored procedure here
	@ArtikelName text,
	@ArtikelNR float,
	@ArtikelLaden float,
	@ArtikelEinheit text,

	@ArtikelMax float

AS
BEGIN
	
	Insert into jurait01_Artikel (NR, Name, Laden, Einheit)
	Values(@ArtikelNR, @ArtikelName, @ArtikelLaden, @ArtikelEinheit)
	Insert into jurait01_Stock1 (Artikel, Stock, Max)
	Values(@ArtikelNR, 0, @ArtikelMax)

END
go

