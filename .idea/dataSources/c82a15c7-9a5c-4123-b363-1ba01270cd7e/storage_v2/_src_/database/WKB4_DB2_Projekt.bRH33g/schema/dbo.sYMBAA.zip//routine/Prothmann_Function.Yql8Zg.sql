CREATE function dbo.Prothmann_Function
( 
@datum	varchar(12)
)
returns int 
begin
declare @ergebnis int;
select @ergebnis = DATEDIFF(yy, @datum, GETDATE());
return @ergebnis;
end;
go

