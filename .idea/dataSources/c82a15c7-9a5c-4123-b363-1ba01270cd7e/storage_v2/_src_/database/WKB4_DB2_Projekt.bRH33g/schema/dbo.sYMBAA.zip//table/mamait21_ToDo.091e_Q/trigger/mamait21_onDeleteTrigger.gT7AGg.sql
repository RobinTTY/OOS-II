CREATE TRIGGER mamait21_onDeleteTrigger
on [dbo].[mamait21_ToDo]
FOR DELETE
AS
BEGIN SET NOCOUNT ON 

	declare @title varchar(64);
	declare @category varchar(64);
	declare @deadline date;
	declare @body varchar(256);
	declare @createon datetime;
	declare @doneon datetime;


	Select @title = title from deleted;
	Select @category = category from deleted; 
	Select @deadline = deadline from deleted; 
	Select @body = body from deleted; 
	Select @createon = createon from deleted;
	Select @doneon = GETDATE();
	
	Insert into [dbo].[mamait21_ToDo_log] values (@title, @category, @deadline, @body, @createon, @doneon)
	print 'inserted';


END
go

