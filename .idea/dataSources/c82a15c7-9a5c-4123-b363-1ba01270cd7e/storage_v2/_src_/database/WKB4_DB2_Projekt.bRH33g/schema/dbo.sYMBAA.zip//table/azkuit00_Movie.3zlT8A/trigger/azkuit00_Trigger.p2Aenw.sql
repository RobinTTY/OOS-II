CREATE TRIGGER azkuit00_Trigger
ON azkuit00_Movie 
FOR DELETE
AS 
BEGIN 
	SET NOCOUNT ON 
	DELETE FROM azkuit00_Rental
    WHERE mID IN(SELECT deleted.mID FROM deleted)
END
go

