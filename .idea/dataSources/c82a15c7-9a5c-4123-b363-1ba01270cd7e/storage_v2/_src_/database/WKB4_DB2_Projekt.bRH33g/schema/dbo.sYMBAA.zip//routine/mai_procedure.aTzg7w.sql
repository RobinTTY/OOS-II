create Procedure dbo.mai_procedure
(@mannschafts_id int)
as
Begin
Set nocount on
 
Select Spiel_ID, Spieltag, Datum, Uhrzeit, Heim, Gast, Tore_Heim, Tore_Gast from dbo.mai_Spiel
where (@mannschafts_id = Heim or @mannschafts_id = Gast) ;

End
go

