CREATE FUNCTION azkuit00_Function
(
	@param1 varchar(30)
) 
RETURNS INT 
AS 
BEGIN 
declare @ergebnis int = NULL;
IF @param1 = 'Movie'
	SELECT @ergebnis = COUNT(*) FROM azkuit00_Movie;
ELSE IF @param1 = 'Customers'
	SELECT @ergebnis = COUNT(*) FROM azkuit00_Customer;
ELSE
	SELECT @ergebnis = COUNT(*) FROM azkuit00_Rental;
RETURN @ergebnis;
END
go

