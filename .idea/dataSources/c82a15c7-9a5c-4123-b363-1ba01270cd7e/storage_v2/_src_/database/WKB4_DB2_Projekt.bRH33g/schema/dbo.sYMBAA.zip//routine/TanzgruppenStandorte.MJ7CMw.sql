Create procedure [dbo].[TanzgruppenStandorte]
(
@Tanzgruppe varchar(50),
@Standort varchar(50)
)
AS
Select TanzgruppenID=@Tanzgruppe FROM emayit01_Tanzgruppe
WHERE StandortID = @Standort;

go

