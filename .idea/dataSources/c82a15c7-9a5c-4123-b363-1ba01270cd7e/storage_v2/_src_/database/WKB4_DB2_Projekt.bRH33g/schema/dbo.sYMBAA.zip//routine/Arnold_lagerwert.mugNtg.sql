create procedure dbo.Arnold_lagerwert
as
select sum(lagerbestand*Preis_je_Stk) as Lagerwert
from Arnold_Schokolade
return 0
go

