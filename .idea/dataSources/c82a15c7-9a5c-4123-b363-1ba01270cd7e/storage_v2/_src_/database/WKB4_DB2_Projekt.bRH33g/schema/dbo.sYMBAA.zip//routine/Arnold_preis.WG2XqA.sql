Create Function dbo.Arnold_preis
( 
@anz int,
@art int
)
returns float
as
begin 
declare @ergebnis float = null;
select @ergebnis=preis_je_stk *@anz
 from dbo.Arnold_Schokolade
 where Artikelnr=@art
 return @ergebnis;
end
go

