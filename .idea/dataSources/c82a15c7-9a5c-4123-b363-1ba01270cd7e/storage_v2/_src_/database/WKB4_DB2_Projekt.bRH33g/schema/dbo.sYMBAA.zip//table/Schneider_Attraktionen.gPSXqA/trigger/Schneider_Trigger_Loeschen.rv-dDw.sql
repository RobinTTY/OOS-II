CREATE TRIGGER Schneider_Trigger_Loeschen ON [dbo].[Schneider_Attraktionen] FOR DELETE
AS
  INSERT INTO [dbo].[Schneider_Protokoll] 
    (Status, Benutzer, Parknummer, Attraktionsname, Themenbereich, Kategorie, Mindestgroesse, Mindestalter) 
  SELECT 'D',USER, Parknummer, Attraktionsname, Themenbereich, Kategorie, Mindestgroesse, Mindestalter 
  FROM deleted
go

