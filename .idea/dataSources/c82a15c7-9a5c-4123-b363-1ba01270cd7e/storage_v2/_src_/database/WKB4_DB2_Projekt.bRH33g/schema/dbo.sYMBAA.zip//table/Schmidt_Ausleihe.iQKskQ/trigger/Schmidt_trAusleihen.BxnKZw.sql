create trigger dbo.Schmidt_trAusleihen
ON dbo.Schmidt_Ausleihe
AFTER INSERT AS
		declare @BNr int
		set @BNr=(select BNr from INSERTED)
	BEGIN
		update Schmidt_Buch
		set Anzahl=Anzahl-1
		where BNr=@BNr
	END
go

