create function dbo.Schlappa_Income
()
returns int
as
begin
declare @menge int
select @menge = count(EID)
from dbo.Schlappa_Einnahmen
return @menge
end;
go

