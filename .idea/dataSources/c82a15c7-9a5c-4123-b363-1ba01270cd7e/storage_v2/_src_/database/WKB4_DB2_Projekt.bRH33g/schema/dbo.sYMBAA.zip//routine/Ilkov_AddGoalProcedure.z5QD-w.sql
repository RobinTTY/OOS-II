CREATE PROCEDURE dbo.Ilkov_AddGoalProcedure
@team int,
@teamid int

AS

IF @team = 1
	UPDATE Ilkov_Matches SET ScoreHomeTeam = (ScoreHomeTeam + 1) WHERE HomeTeam = @teamid;
ELSE
	UPDATE Ilkov_Matches SET ScoreAwayTeam = (ScoreAwayTeam + 1) WHERE AwayTeam = @teamid;
go

