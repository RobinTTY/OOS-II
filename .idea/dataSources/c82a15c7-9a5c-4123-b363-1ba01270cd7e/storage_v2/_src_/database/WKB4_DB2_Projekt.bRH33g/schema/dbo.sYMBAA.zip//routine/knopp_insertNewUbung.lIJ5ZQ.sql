create procedure knopp_insertNewÜbung
@übungsid int,
@übung varchar(30)
as
insert into Knopp_tblÜbungen (IDÜbungen, übungen) 
values(@übungsid, @übung)
go

