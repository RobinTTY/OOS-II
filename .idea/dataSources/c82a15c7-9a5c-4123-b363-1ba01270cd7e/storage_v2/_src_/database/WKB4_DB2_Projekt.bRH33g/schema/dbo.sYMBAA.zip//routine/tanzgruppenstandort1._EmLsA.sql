create procedure [dbo].[tanzgruppenstandort1]
@Standort varchar(50)
as
select Tanzgruppenname
from emayit01_Tanzgruppe
Where StandortID = @Standort;


go

