create procedure [dbo].[tanzgruppenstandort5]
@Standort varchar(50)
as
select tg.Tanzgruppenname
from emayit01_Tanzgruppe tg
join emayit01_Standort st on tg.StandortID = st.StandortID
Where Standort = 'Stuttgart';


go

