--Stored Procedure
/*alter procedure 
dbo.sekait04_MMT
AS
BEGIN
select count(*) 
from sekait04_Mitglieder 
where Ort='Stuttgart';
END

exec dbo.sekait04_MMT;
*/
--Trigger
CREATE TRIGGER dbo.sekait04_Zeilen_Löschen 
ON dbo.sekait04_Termin
AFTER DELETE
AS 
BEGIN 

Select CURRENT_TIMESTAMP, HOST_NAME(),SUSER_NAME(), 'DELETE', 'Termin', TerminID, MitgliedID, TrainerID, Datum, Uhrzeit
FROM Deleted
END


go

