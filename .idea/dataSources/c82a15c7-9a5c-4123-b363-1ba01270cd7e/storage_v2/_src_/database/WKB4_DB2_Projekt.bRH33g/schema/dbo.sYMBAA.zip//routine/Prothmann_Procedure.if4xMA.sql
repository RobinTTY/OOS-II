CREATE procedure dbo.Prothmann_Procedure
				@param1 varchar(100),
				@param2 varchar(100),
				@param3 date
				as
				insert into dbo.Prothmann_Persons (
				Name, Vorname, Geburtsdatum)
				values(@param1, @param2, @param3);
go

