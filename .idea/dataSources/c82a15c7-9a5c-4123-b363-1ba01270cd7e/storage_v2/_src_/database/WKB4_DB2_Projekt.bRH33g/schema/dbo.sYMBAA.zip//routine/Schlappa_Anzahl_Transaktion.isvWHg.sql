create function Schlappa_Anzahl_Transaktion
()
returns int
as
begin
declare @anzahl int
select @anzahl = count(AID)
from dbo.Schlappa_Ausgaben
return @anzahl
end;
go

