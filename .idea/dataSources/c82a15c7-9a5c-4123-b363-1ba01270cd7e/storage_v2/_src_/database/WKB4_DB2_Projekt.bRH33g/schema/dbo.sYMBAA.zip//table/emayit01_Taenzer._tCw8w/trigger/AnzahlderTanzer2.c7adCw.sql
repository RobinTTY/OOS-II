CREATE trigger dbo.AnzahlderTanzer2
on dbo.emayit01_Taenzer
for insert
as
begin
set nocount on

declare @Anzahl int;

select @Anzahl = count(TaenzerID) from emayit01_Taenzer;


print 'Es gibt ' +cast(@Anzahl as varchar)+ ' Taenzer!'

End
go

