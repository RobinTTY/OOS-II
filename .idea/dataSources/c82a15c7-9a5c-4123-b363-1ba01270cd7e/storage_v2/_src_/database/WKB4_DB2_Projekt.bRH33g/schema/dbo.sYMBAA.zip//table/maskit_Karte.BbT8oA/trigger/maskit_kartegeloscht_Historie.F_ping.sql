create trigger maskit_kartegelöscht_Historie
on maskit_Karte
After DELETE
AS
BEGIN
insert into maskit_Speisekarten_Historie
(Kname,KID)
Select Kname,KID
from deleted
end
go

