CREATE FUNCTION [dbo].[osusit00_countArtist]
(
	@artist varchar(255)
)
RETURNS INT
AS
BEGIN
	DECLARE @anzahl int;
	IF @artist = 'all'
	BEGIN
		SELECT @anzahl = (Select count(distinct artist) FROM WKB4_DB2_Projekt.dbo.osusit00_mp3Tags)
	END
	ELSE
	BEGIN
		SELECT @anzahl = (Select count(*) FROM WKB4_DB2_Projekt.dbo.osusit00_mp3Tags WHERE artist=@artist)
	END
	RETURN @anzahl
END
go

