create function dbo.mai_function
(@mannschafts_id int) returns int
as 
Begin
Declare @heim int
Declare @gast int

Select @heim = Sum(Tore_Heim) from dbo.mai_Spiel
where @mannschafts_id = Heim

Select @gast = SUM(Tore_Gast) from dbo.mai_Spiel 
where @mannschafts_id = Gast

return @gast + @heim

End
go

