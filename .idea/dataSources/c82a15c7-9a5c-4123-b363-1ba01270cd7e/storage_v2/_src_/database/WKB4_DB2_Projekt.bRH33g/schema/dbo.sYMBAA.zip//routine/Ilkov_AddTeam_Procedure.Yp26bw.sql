CREATE PROCEDURE dbo.Ilkov_AddTeam_Procedure
@name varchar(255)

AS

IF EXISTS (SELECT TeamName FROM Ilkov_Teams WHERE TeamName = @name)
	BEGIN
		PRINT  'There is already a team with that name. Try again!'
		RETURN(0)
	END


ELSE
	BEGIN 
		INSERT INTO Ilkov_Teams (TeamName) VALUES (@name);
		PRINT('Team is added')
		RETURN(1)
	END
go

