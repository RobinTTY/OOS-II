CREATE PROCEDURE daglit01_proc_insert_task @name varchar(50), @description varchar(MAX), @creator int, @asignee int, @project int
AS
INSERT INTO daglit01_task (name, description, created, creator, asignee, project)
VALUES (@name, @description, CURRENT_TIMESTAMP, @creator, @asignee, @project)

SELECT IDENT_CURRENT('daglit01_task') as id
RETURN;
go

