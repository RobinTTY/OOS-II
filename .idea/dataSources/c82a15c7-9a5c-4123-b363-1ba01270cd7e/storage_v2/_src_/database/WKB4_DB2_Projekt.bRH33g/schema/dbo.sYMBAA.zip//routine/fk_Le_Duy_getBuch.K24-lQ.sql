CREATE FUNCTION dbo.fk_Le_Duy_getBuch
(
	@BuchID int
)
RETURNS varchar(50)
AS
BEGIN
		IF EXISTS (SELECT BuchID FROM Le_Duy_Buch WHERE BuchID=@BuchID)
		DECLARE @Buchtitel varchar(50)
		SELECT @Buchtitel = b.Buchtitel
		FROM Le_Duy_Buch b
		WHERE b.BuchID =@BuchID
		RETURN @Buchtitel
END;
--sele
go

