/*CREATE PROCEDURE knopp_getÜbungsID
@übungID int,
@Übung varchar(30) = null
AS
insert into knopp_tblübungen (IDÜbungen, übungen)
values (@übungID,@Übung)
return 0
go*/
--exec knopp_getÜbungsID @übungID = 19 , @Übung = 'Bankdrücken'
--select * from  Knopp_tblÜbungen
/*CREATE TRIGGER Knopp_TriggerAfterInsert ON [dbo].[knopp_tblübungen]
FOR INSERT AS
BEGIN
  SET NOCOUNT ON
  Select * from Knopp_tblÜbungen
END*/
create procedure knopp_insertInInfo
@IDInfo int,
@IDÜbung int,
@IDDatum int,
@Gewicht float,
@Wiederholungen int
as
insert into Knopp_tblInfo (IDInfo,IDÜbungen,IDDatum,Gewicht,Wiederholungen)
values(@Gewicht,@IDÜbung,@IDDatum,@Gewicht,@Wiederholungen)
go

