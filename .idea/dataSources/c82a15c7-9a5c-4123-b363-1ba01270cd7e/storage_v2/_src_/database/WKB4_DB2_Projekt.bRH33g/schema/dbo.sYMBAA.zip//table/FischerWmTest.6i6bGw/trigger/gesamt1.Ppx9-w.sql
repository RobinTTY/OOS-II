-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER gesamt1
ON [dbo].[FischerWmTest]
AFTER INSERT
AS
BEGIN
SET NOCOUNT ON
DECLARE @counter int
DECLARE @gesamt int
SET @counter =(Select Counter from inserted)
SET @gesamt = (Select GesamtSpieler from inserted)

UPDATE dbo.FischerWmTest
SET GesamtSpieler=GesamtSpieler+@counter
WHERE Counter = @counter AND GesamtSpieler = @gesamt
END

go

