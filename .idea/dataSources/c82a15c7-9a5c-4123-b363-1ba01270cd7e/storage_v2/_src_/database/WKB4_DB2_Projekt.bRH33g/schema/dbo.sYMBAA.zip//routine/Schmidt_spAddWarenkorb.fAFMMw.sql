CREATE procedure dbo.Schmidt_spAddWarenkorb
@LeserID int, @BNr int, @Anzahl int

as
begin

	insert into Schmidt_Warenkorb (BNr, Autor, Titel, Verlag, Jahr) 
	select BNr, Autor, Titel, Verlag, Jahr from Schmidt_Buch where BNr=@BNr

	update Schmidt_Warenkorb set RDat = (select dbo.Schmidt_fRueckgabe())
	
	update Schmidt_Warenkorb set Anzahl = @Anzahl
	update Schmidt_Warenkorb set LNr = @LeserID
	select * from Schmidt_Warenkorb

end
go

