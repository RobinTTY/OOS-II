CREATE TRIGGER sekait04_Trainer1
ON dbo.sekait04_Trainer
FOR INSERT
AS 
BEGIN 
	SET NOCOUNT ON 
	Declare @Anzahl int;

	Select @Anzahl = count(*) from sekait04_Trainer;

	print 'Derzeit gibt es ' + cast(@Anzahl as varchar)+ ' '+ 'Trainer ';
	 
END
go

