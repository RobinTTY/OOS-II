CREATE Procedure [dbo].[Zerbe_AddBoat]
(
@Bootnr int,
@Typ varchar (20),
@Kaufdatum date
)
AS
DECLARE @count int = 0

SELECT @count = count(*)
FROM Zerbe_Boot
WHERE Bootnr = @Bootnr

IF (@count = 0)
BEGIN
INSERT INTO Zerbe_Boot VALUES (@Bootnr,@Typ,@Kaufdatum)
PRINT 'Boot wurde hinzugefügt.'

END
ELSE 
PRINT 'Bootnummer bereits vergeben.';
go

