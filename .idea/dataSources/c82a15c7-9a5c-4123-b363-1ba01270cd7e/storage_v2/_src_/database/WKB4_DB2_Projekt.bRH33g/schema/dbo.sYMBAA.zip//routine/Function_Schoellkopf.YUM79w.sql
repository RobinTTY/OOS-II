Create Function dbo.Function_Schoellkopf ()
RETURNS table
AS
RETURN(
Select st.spielerID,s.name,s.vorname, sum(e.betrag) as Summe
FROM dbo.Schoellkopf_Spieler as s
JOIN dbo.Schoellkopf_Strafen as st
ON st.spielerID =  s.spielerID
JOIN dbo.Schoellkopf_StrafKatalog as e
ON st.beschreibungID = e.beschreibungID
Group BY st.spielerID, s.name, s.vorname
)
go

