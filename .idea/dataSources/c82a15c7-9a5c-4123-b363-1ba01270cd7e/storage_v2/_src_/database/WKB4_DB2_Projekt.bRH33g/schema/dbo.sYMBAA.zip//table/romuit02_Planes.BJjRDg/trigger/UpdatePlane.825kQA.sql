CREATE TRIGGER UpdatePlane
  ON dbo.romuit02_Planes
  FOR UPDATE, DELETE 
AS
  BEGIN
    INSERT INTO romuit02_PlaneHistory SELECT * FROM deleted
  END
go

