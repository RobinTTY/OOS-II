create procedure dbo.Schmidt_spAusleihenTest

as 
begin
	declare @joinLNr table(
	WNr INT NOT NULL,
	LNr INT NOT NULL,
	Nachname VARCHAR(50) NULL,
	Vorname VARCHAR(50) NULL,
	BNr INT NOT NULL,
	Anzahl INT NULL,
	RDat date NULL )

	insert into @joinLNr 
	select w.WNr, l.LNr, l.Nachname, l.Vorname, w.BNr, w.Anzahl, w.RDat
	from Schmidt_Leser l
	inner join Schmidt_Warenkorb w on l.LNr = w.LNr

	Declare @minWNr as int = (select min(WNr) from Schmidt_Warenkorb); 
	Declare @maxWNr as int = (select max(WNr) from Schmidt_Warenkorb);

		WHILE (@minWNr <= @maxWNr)
			BEGIN

			insert into Schmidt_Ausleihe (LNr, Nachname, Vorname, BNr, Anzahl, RDat)
			select LNr, Nachname, Vorname, BNr, Anzahl, RDat from @joinLNr where WNr=@minWNr
			
			select @minWNr = @minWNr+1

			END
end
go

