
/*CREATE TABLE dbo.pafait_fahrplan (
    BahnName varchar(255),
    Start_Bahnhof varchar(255),
    Ziel_Bahnhof varchar(255),
    Fahrzeit varchar(255)
);*/
CREATE function [dbo].[auswahl_bahn]
(

)
returns INT
As 
Begin
declare @anzahl int;
select @anzahl = (Select count(distinct BahnName) from WKB4_DB2_Projekt.dbo.pafait_fahrplan)

return @anzahl
End


/*create TRIGGER trigger_train 
on dbo.pafait_fahrplan
for insert
as 
begin

set nocount on
declare @anz float;

select @anz =count(*) from dbo.pafait_fahrplan;

print 'derzeit sind'+ cast (@anz as varchar)+' BahnStecken gespeichert';

END
*/

/*
create Procedure dbo.pafait_add_train2

AS

Return 0
*/
/*Alter Procedure dbo.pafait_add_train
    @BahnName varchar(255),
    @Start_Bahnhof varchar(255),
    @Ziel_Bahnhof varchar(255),
    @Fahrzeit varchar(255)
AS

insert into WKB4_DB2_Projekt.dbo.pafait_fahrplan
Values(@BahnName,@Start_Bahnhof,@Ziel_Bahnhof,@Fahrzeit);
print'Bahnstrecke angelegt'

Return 0
*/


go

