
 /*
create PROCEDURE Selimi_Mitarbeiter_Select @Nummer int
AS

begin
SELECT name 
FROM Selimi_Mitarbeiter 
WHERE PersNr = @Nummer

return Name
END
*/
---exec Selimi_Mitarbeiter_Select @Nummer = 1


/*
create FUNCTION Selimi_SummeGehaltAlle
(
	
)
returns int
AS 
Begin
	DECLARE @ret int;
	SELECT @ret = Sum(gehalt)
	FROM Selimi_Mitarbeiter m
	Join Selimi_Gehalt g on m.Gehalt_id=g.id

	return @ret
End
*/
--SELECT [dbo].[Selimi_SummeGehaltAlle] ()

CREATE TRIGGER Selimi_tryIts
 ON Selimi_Mitarbeiter
 After Insert
 AS 
 BEGIN 

	SET NOCOUNT ON 
	--handle delete data, insert into both the history and the log tables 
    INSERT INTO Selimi_Mitarbeiter_Insert_log (pers, name, vorname,zeitstempel) 
     select PersNr, Name, Vorname,current_timestamp
	 from inserted
 END
 --insert into Selimi_Mitarbeiter (PersNr,name,vorname,beruf_id,Gehalt_id)
 --values (22,'a','b',5,3)
  
 
 /*insert into Selimi_Mitarbeiter (PersNr,name,vorname,Beruf_id,Gehalt_id)
 values(24,'pan','peter',1,1)
 */
 --select * from Selimi_Mitarbeiter_Insert_log


 go

