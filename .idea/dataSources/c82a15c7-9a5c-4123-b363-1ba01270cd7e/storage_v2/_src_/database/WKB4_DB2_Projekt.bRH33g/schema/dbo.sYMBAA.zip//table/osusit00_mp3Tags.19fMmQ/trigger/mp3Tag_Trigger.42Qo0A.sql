--CREATE TRIGGER mp3Tag_Trigger 
CREATE TRIGGER [dbo].[mp3Tag_Trigger] 
ON [dbo].[osusit00_mp3Tags]
FOR INSERT
AS 
BEGIN
	SET NOCOUNT ON
	DECLARE @anzahl FLOAT;
	SELECT @anzahl = count(*) FROM dbo.osusit00_mp3Tags;
	PRINT 'Es sind derzeit ' + CAST(@anzahl AS VARCHAR) + ' Tags gespeichert!';
END
go

