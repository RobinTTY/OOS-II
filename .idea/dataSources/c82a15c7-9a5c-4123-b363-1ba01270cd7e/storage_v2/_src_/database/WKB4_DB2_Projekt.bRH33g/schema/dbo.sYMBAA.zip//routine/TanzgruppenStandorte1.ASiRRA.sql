Create procedure [dbo].[TanzgruppenStandorte1]
(
@Tanzgruppe varchar(50),
@Standort varchar(50)
)
AS
Select Tanzgruppenname FROM emayit01_Tanzgruppe
WHERE StandortID = @Standort;


go

