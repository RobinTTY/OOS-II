
 /*
create PROCEDURE Selimi_Mitarbeiter_Select @Nummer int
AS

begin
SELECT name 
FROM Selimi_Mitarbeiter 
WHERE PersNr = @Nummer

return Name
END
*/
---exec Selimi_Mitarbeiter_Select @Nummer = 1

create PROCEDURE Selimi_Mitarbeiter_Select_Vorname @Nummer int
AS

Begin
SELECT Vorname 
FROM Selimi_Mitarbeiter 
WHERE PersNr = @Nummer


END
 go

