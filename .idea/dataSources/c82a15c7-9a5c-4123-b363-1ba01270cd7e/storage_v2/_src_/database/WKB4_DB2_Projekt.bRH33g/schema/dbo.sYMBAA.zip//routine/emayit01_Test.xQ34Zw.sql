CREATE PROCEDURE dbo.emayit01_Test
AS
BEGIN
SELECT * FROM emayit01_Taenzer
END;
go

