
-- SELECT * FROM dbo.mobeit00_order_view;

-- SELECT dbo.mobeit00_getOrderValue()

-- Total Value of all orders
-- SELECT SUM(dbo.mobeit00_coffee.price * dbo.mobeit00_orders.quantity)
-- FROM dbo.mobeit00_coffee
-- INNER JOIN dbo.mobeit00_orders ON dbo.mobeit00_coffee.id = dbo.mobeit00_orders.coffee_id

-- SELECT DATEDIFF(dd, MIN(order_date), MAX(order_date)) AS 'Anzahl Tage'
--FROM dbo.mobeit00_orders


-- EXEC dbo.mobeit00_createOrder 4, 10

CREATE PROCEDURE
dbo.mobeit00_createOrder
	@coffee_id int,
	@order_quantity int
AS
	INSERT INTO dbo.mobeit00_orders (order_date, quantity, coffee_id) VALUES (GETDATE(), @order_quantity, @coffee_id)
RETURN 0


--INSERT INTO dbo.mobeit00_coffee (name, price, type) VALUES ('Jacobs Krönung Crema, Kaffee', 13.99, 1)

-- DELETE FROM dbo.mobeit00_orders WHERE order_date IS NOT NULL;


-- INSERT INTO dbo.mobeit00_orders (quantity, coffee_id) VALUES (5, 2);

-- SELECT * FROM dbo.mobeit00_order_view;

-- ALTER VIEW dbo.mobeit00_order_view
-- AS
-- SELECT dbo.mobeit00_orders.id, dbo.mobeit00_orders.order_date, dbo.mobeit00_orders.quantity, dbo.mobeit00_coffee.name 
-- FROM dbo.mobeit00_orders
-- INNER JOIN dbo.mobeit00_coffee ON dbo.mobeit00_orders.coffee_id = dbo.mobeit00_coffee.id;

--CREATE VIEW dbo.mobeit00_coffee_view AS
--SELECT [dbo].mobeit00_coffee.name,[dbo].mobeit00_type.type AS beans_type, price
--FROM [dbo].mobeit00_coffee
--INNER JOIN dbo.mobeit00_type ON dbo.mobeit00_coffee.type = dbo.mobeit00_type.type;


-- INSERT INTO dbo.mobeit00_coffee (name, price, type) VALUES ('STRONG UNTRADITIONAL BLACK Kaffee Espresso', 23.00, 2);
-- SELECT * FROM WKB4_DB2_Projekt.dbo.mobeit00_coffee;

go

