CREATE FUNCTION [dbo].[charit_bewertungsDurchschnitt](@title varchar(200))
RETURNS int
AS
BEGIN
	DECLARE @mid int;
	SELECT @mid = SUM(b.bewertung)/count(*)
	FROM charit_literatur_bewertung b
	WHERE b.litTitle= @title
	RETURN (@mid)
END;
go

