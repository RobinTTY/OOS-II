
--insert into WKB4_DB2_Projekt.dbo.pafait_fahrplan Values('S5','Stuttgart_hbf','Ludwigsburg','15 min');
--insert into WKB4_DB2_Projekt.dbo.pafait_fahrplan2 Values('S4','Bad Cannstatt','Stuttgart_hbf',(CAST(rand()*(120-90)+90 AS INT)));
--drop table  WKB4_DB2_Projekt.dbo.pafait_fahrplan
--delete from  WKB4_DB2_Projekt.dbo.pafait_fahrplan2 where Bahnname='S5'
--select * from WKB4_DB2_Projekt.dbo.pafait_fahrplan2

--EXEC dbo.pafait_add_train2 S5,dd,hhh,aaa
--select dbo.anzahl_unter_bahnen()
--select * from WKB4_DB2_Projekt.dbo.pafait_fahrplan



--select dbo.gewiit_MovieFunction2
--select * from WKB4_DB2_Projekt.dbo.gewiit_Movies2
create function dbo.test
(

)
returns INT
As 
Begin
declare @anzahl int;
select @anzahl = (Select count(distinct Movietitle) from WKB4_DB2_Projekt.dbo.gewiit_Movies2)

return @anzahl
End

go

