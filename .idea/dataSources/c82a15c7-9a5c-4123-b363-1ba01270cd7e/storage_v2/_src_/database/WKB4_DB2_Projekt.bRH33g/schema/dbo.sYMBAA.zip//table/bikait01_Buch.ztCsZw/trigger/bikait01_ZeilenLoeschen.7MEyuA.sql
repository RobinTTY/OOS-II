CREATE TRIGGER bikait01_ZeilenLoeschen
ON bikait01_Buch
FOR DELETE
AS
BEGIN
SET NOCOUNT OFF 
DELETE FROM bikait01_Leihe
WHERE BuchID IN(SELECT deleted.BuchID FROM deleted)
END;


go

