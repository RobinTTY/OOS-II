CREATE TRIGGER bikait01_ZeilenLoeschen
ON bikait01_Buch
FOR DELETE
AS
BEGIN
	SET NOCOUNT ON 
	DELETE FROM bikait01_Leihe
	WHERE BuchID IN(SELECT deleted.BuchID FROM deleted)
	PRINT 'Die Leihe wurde erfolgreich von der Tabelle Ausleihe gelöscht.' 
END;
go

