CREATE FUNCTION [dbo].[Ilkov_ScoreGoal]
(
@team int,
@teamid int
)
RETURNS INT
AS
BEGIN

-- Check the current goals
DECLARE @currentGoals int;
IF @team = 1
	SET @currentGoals = (SELECT ScoreHomeTeam as currentGoals FROM Ilkov_Matches WHERE HomeTeam = @teamid);
ELSE
	SET @currentGoals = (SELECT ScoreAwayTeam as currentGoals FROM Ilkov_Matches WHERE AwayTeam = @teamid);
 

-- return the total goals
RETURN @currentGoals + 1
END
go

