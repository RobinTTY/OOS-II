CREATE PROCEDURE jurait01_Update
	@Artikel as float,
	@Stock as float

AS
BEGIN
	Update jurait01_Stock1 Set Stock = (Stock + @Stock) Where Artikel = @Artikel
END
go

