-- =============================================
-- Author:		Schneider, Nico
-- Create date: 09/12/2018
-- Description:	Aufsummieren der Ergebnisse
-- =============================================
CREATE FUNCTION [dbo].[Schneider_Attraktionen_Anzahl]
(
	-- Add the parameters for the function here
	@Alter int,
		@Groesse float
)

RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @result float;

	-- Add the T-SQL statements to compute the return value here
	SELECT @result = COUNT(Parknummer)
	FROM [dbo].[Schneider_Attraktionen] AS attrakt 
		WHERE attrakt.Mindestgroesse <= @Groesse
		AND (attrakt.Mindestalter <= @Alter
		OR attrakt.Mindestalter IS NULL);
	IF (@result IS NULL)   
        SET @result = 0;  

	-- Return the result of the function
	RETURN @result;

END
go

