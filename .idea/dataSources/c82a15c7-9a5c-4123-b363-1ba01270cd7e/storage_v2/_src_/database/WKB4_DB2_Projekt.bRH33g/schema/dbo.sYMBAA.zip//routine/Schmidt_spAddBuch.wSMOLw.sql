CREATE procedure dbo.Schmidt_spAddBuch
(@Autor VARCHAR(50), @Titel VARCHAR(100), 
@Verlag VARCHAR(50), @Jahr INT, @Anzahl INT NULL)

as
begin
	declare @pruf int
	set @pruf=(select dbo.Schmidt_fPrufAddBuch(@Autor,@Titel)) 
	
	if (@pruf=1)
		begin
			update Schmidt_Buch 
			set Anzahl= Anzahl+1 
			where @Autor=Autor and @Titel=Titel 
		end
	else
		begin 
			insert into Schmidt_Buch
			values (@Autor, @Titel, 
			@Verlag, @Jahr, @Anzahl)
		end

	select * from Schmidt_Buch 
	where @Autor=Autor and @Titel=Titel

end
go

