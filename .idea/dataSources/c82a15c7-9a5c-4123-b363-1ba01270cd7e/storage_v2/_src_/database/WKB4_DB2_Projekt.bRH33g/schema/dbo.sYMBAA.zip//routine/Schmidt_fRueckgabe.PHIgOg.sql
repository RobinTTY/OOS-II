CREATE FUNCTION dbo.Schmidt_fRueckgabe
()
RETURNS date
AS
BEGIN
 
 declare @RDat date
 select @RDat = DATEADD(DAY, +30, GETDATE())
 
 RETURN @RDat

END
go

