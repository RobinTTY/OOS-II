Create Procedure

dbo.delete_procedure

AS
 
 DELETE FROM lukasTodo;

 RETURN 0
go

