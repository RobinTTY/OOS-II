CREATE PROCEDURE [dbo].[bauzit00_Gast_1]
   @ID int,
   @Name VARCHAR(30),
   @Kontaktdaten VARCHAR(30)

AS
BEGIN
    INSERT INTO dbo.bauzit00_Tischreservierung_Gast(ID, Name, Kontaktdaten) 
    SELECT @ID, @Name, @Kontaktdaten 
        FROM dbo.bauzit00_Tischreservierung
        WHERE ID = @ID
END
go

