Create Function get_jurait01_Einkaufszettel()

Returns TABLE
	 RETURN  (Select * From jurait01_Einkaufszettel  )
go

