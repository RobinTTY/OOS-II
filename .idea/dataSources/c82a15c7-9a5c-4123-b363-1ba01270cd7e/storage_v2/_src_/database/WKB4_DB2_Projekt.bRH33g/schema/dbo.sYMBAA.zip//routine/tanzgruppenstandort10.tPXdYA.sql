CREATE procedure dbo.tanzgruppenstandort10
as
BEGIN
select tg.Tanzgruppenname
from emayit01_Tanzgruppe tg
join emayit01_Standort st on tg.StandortID = st.StandortID
Where st.Standort = 'Esslingen Mitte'
END
go

