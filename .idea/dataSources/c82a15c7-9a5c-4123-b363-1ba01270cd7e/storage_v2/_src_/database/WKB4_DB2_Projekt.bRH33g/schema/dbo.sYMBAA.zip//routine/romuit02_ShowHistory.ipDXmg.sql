CREATE FUNCTION romuit02_ShowHistory(@icao varchar(10))
  RETURNS TABLE
  AS
  RETURN (
      SELECT * FROM romuit02_PlaneHistory WHERE icao = @icao
  )
go

