CREATE PROCEDURE mamait21_Insert_Todo3

	@title Varchar(64),
	@category Varchar(64),
	@deadline date, 
	@body Varchar(256),
	@done int

	AS

	declare @createon datetime;
	select @createon = getDate();

	Insert into [dbo].[mamait21_ToDo]
	values(@title, @category, @deadline, @body, @createon, @done);


	Return 0
go

