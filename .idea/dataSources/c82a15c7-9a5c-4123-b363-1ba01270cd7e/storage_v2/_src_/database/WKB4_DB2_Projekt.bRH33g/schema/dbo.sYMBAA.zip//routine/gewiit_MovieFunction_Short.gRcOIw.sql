CREATE FUNCTION [dbo].[gewiit_MovieFunction_Short]()
RETURNS INT
AS
BEGIN
declare @var1 int;
select @var1 =  Sum([MovieLength in min])
From dbo.gewiit_Movies_Short;
--insert code here
RETURN @var1
END;
go

