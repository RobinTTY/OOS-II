
 
create PROCEDURE Selimi_Mitarbeiter_Select @Nummer int
AS

begin
SELECT name 
FROM Selimi_Mitarbeiter 
WHERE PersNr = @Nummer

END
go

