CREATE FUNCTION dbo.kopilas_Deckpreis(@decknummer int)
RETURNS FLOAT
AS
BEGIN
	declare @gesamt float
	select @gesamt=sum((wert*kopien)) from kopilas_Karte
	where DeckNR = @decknummer
	RETURN @gesamt
END

go

