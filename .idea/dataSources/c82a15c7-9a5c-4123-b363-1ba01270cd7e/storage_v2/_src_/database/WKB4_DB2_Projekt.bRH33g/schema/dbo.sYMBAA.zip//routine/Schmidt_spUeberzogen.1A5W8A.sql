create procedure dbo.Schmidt_spUeberzogen

as 
begin
 declare @heute date
 set @heute = GETDATE()

 select * from Schmidt_Ausleihe 
 where RDat<@heute

end
go

