Create procedure Produktnameinkarte
@Kartename varchar(30)
AS
Declare @Kartenname varchar(30);
Select p.PName from maskit_Produkt as p join Produkt_in_Karte as k on 
p.PID=k.PID
Where k.KID = dbo.Kartenname_zu_ID(@Kartename)
go

