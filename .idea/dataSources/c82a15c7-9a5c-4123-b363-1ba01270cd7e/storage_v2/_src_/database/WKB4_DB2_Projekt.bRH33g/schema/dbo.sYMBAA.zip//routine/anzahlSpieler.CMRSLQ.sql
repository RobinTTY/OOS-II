create function anzahlSpieler
()
returns int
as
begin
declare @anzahl int 
select @anzahl= count(Vorname)
from leugit00_Tore


return @anzahl
end;


--select meisteTore(Hohenacker);
go

