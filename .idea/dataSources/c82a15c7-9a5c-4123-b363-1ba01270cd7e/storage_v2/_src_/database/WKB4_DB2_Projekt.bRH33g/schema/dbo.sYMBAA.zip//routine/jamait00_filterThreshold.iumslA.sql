CREATE PROCEDURE
[dbo].[jamait00_filterThreshold]
@threshold decimal(7,2)
AS
BEGIN
	SET NOCOUNT ON;
	SELECT * FROM WKB4_DB2_Projekt.dbo.jamait00_durchfluss 
	WHERE Diff_proz >= @threshold
END	
	RETURN 0
go

