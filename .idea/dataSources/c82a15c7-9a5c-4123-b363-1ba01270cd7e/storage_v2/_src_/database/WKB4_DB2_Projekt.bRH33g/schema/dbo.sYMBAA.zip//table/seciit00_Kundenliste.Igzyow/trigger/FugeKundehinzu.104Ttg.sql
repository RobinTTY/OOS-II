
CREATE TRIGGER [dbo].[FügeKundehinzu]
   ON   [dbo].[seciit00_Kundenliste]
   FOR INSERT 
AS 
BEGIN
	Declare @Anzahl int;
	Select @Anzahl = count(*) from dbo.seciit00_Kundenliste;
	print 'Insgesamt gibt es jetzt ' + CAST(@Anzahl as varchar)+ ' verschiedene Kunden' ;

END
go

