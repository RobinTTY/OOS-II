-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[schoelpple_heldenhinzufuegen] 
	-- Add the parameters for the stored procedure here
	@NeueHeldenID varchar (50),
	@NeuerHeldenname varchar(50),
	@NeuesAttribut varchar(50),
	@NeueRolle varchar (50)
AS
BEGIN

	insert into dbo.Schoelpple_Dota_Helden 
	values (@NeueHeldenID, @NeuerHeldenname, @NeuesAttribut, @NeueRolle);

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	
END
go

