CREATE FUNCTION[dbo].[villalilla_checkKey]
(
	@gamekey varchar(30)
)
RETURNS varchar(8)
AS
BEGIN
	DECLARE @found int;

	SELECT @found = COUNT(*) 
	FROM [dbo].[villalilla_keys]
	WHERE gamekey=@gamekey;
	IF @found = 1 RETURN 'On sale';

	SELECT @found = COUNT(*) 
	FROM [dbo].[villalilla_keys_dellog]
	WHERE gamekey=@gamekey;
	IF @found = 1 RETURN 'Removed';

	RETURN 'Unknown'
END
go

