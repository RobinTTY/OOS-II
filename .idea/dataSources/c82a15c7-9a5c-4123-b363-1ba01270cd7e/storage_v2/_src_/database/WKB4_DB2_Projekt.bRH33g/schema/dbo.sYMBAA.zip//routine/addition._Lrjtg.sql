CREATE FUNCTION dbo.addition
(
   @param1 int,@param2 int
   
   )
   RETURNS INT

   AS

   BEGIN 

   Return @param1+@param2

   END


go

