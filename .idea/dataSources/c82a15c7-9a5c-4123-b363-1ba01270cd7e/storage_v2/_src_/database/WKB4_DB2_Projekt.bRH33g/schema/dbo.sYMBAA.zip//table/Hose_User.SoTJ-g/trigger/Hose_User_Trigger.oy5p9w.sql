CREATE Trigger	[dbo].[Höse_User_Trigger]
On				[dbo].[Höse_User]

After Delete

As

Begin

Insert Into		dbo.Höse_Deleted

				(	Zeitstempel,
					Hostname,
					Username,
					Typ,
					Tabelle,
					U_ID,
					U_NAME
				)

Select			
				CURRENT_TIMESTAMP,
				HOST_NAME(),
				SUSER_NAME(),
				'DELETE',
				'dbo.Höse_Deleted',
				U_ID,
				U_Name				

From			Deleted;

Print			'Deleted Line @ Table dbo.Höse_User';

End
;
go

