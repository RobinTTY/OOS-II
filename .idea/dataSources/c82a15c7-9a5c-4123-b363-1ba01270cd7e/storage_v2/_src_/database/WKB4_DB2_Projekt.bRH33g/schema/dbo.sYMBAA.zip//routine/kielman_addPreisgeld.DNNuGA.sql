/*1.)
CREATE PROCEDURE
kielman_uebersicht_strafe
AS
BEGIN
SELECT st.spielernr AS spielernummer, sp.name AS nachname, sp.vorname, SUM(st.strafe)
FROM [DB2-Spieler2].[dbo].[Gunesch_strafe] st
INNER JOIN [DB2-Spieler2].[dbo].[Gunesch_spieler] sp
ON st.spielernr = sp.spielernr
GROUP BY st.spielernr, sp.name, sp.vorname;
RETURN 0;
END

2.) ALTER für überschreiben
CREATE PROCEDURE
kielman_uebersicht_strafe_2
@auswahl varchar(6)
AS
BEGIN
if @auswahl = 'gesamt'
	begin
	SELECT st.spielernr AS spielernummer, sp.name AS nachname, sp.vorname, SUM(st.strafe)
	FROM [DB2-Spieler2].[dbo].[Gunesch_strafe] st
	INNER JOIN [DB2-Spieler2].[dbo].[Gunesch_spieler] sp
	ON st.spielernr = sp.spielernr
	GROUP BY st.spielernr, sp.name, sp.vorname;
	end
else if @auswahl = 'einzel'
	begin
	SELECT st.spielernr AS spielernummer, sp.name AS nachname, sp.vorname
	FROM [DB2-Spieler2].[dbo].[Gunesch_strafe] st
	INNER JOIN [DB2-Spieler2].[dbo].[Gunesch_spieler] sp
	ON st.spielernr = sp.spielernr
	ORDER BY st.spielernr;
	end
else
	begin
	print 'wählen Sie entweder "gesamt" oder "einzel"';
	end
END
3.)  */
CREATE PROCEDURE [dbo].[kielman_addPreisgeld]
(
@WettkampfID int,
@Preisgeld money
)
AS
--Selection 1: Lokale Variable
declare @count int = 0

--Selection 2: Prüfung ob schon ein Preisgeld für den Wettkampf vorhanden ist
SELECT @count = count(*)
FROM [dbo].[Kielman_preisgeld]
WHERE wettkampf_id = @WettkampfID

--Selection 3: Preisgeld einfügen, wenn noch kein Eintrag vorhanden ist
IF (@count = 0)
	begin
	insert into Kielman_preisgeld values (@WettkampfID, @Preisgeld, NULL)
	print 'Preisgeld angelegt'
	end
ELSE 
	print 'Preisgeld für diese Wettkampf ID bereits vorhanden'
/*
Trigger:
1.)  
CREATE TRIGGER Kielman_Trigger
ON 
*/
go

