CREATE PROCEDURE dbo.bikait01_Ausleihen
AS
BEGIN
SELECT COUNT(*) AS 'Ausleiher mit Anfangsbuchstaben M'
FROM bikait01_Leihe AS lei
JOIN bikait01_Ausleiher AS auslei ON auslei.AusleiherID = lei.AusleiherID
WHERE auslei.Vorname LIKE 'M%'
END
go

