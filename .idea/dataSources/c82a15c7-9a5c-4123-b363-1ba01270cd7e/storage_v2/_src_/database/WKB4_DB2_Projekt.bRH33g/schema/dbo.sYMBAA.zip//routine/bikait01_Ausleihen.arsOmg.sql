CREATE PROCEDURE dbo.bikait01_Ausleihen
AS
BEGIN
SELECT COUNT(*) AS 'Ausleiher mit Anfangsbuchstaben M'
FROM bikait01_Ausleiher
WHERE Vorname LIKE 'M%'
END
go

