-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[vawait00_matchDrohneWettbewerb] 
	-- Add the parameters for the stored procedure here
	
	@Drohne varchar(255)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT w.name as Veranstaltung, w.austragungsort as Austragungsort, w.veranstaltungsdatum as Veranstaltungsdatum
	from vawait00_Drohnen as d
	join vawait00_Teilnahme as t
	on d.DrohnenID = t.DrohnenID
	join vawait00_Wettbewerbe as w
	on t.WettbewerbID = w.WettbewerbID
	where d.name = @Drohne;
END
go

