CREATE function [dbo].[leugit00_anzahlSpieler]
()
returns int
as
begin
declare @anzahl int 
select @anzahl= count(Vorname)
from leugit00_Spieler


return @anzahl
end;


--select 
go

