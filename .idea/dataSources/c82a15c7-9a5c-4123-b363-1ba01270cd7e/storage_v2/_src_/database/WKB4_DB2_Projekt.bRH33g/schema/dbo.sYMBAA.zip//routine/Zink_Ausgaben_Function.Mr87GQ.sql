create function dbo.Zink_Ausgaben_Function
(
@var1 float,
@var2 float
)
returns float
as
begin
return @var1+@var2
end
go

