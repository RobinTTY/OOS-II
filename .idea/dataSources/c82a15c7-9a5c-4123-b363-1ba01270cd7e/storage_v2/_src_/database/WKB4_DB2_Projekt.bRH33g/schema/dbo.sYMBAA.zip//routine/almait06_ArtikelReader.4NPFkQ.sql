CREATE PROCEDURE dbo.almait06_ArtikelReader
@ArtikelID int = null,
@LadenID int = null,
@Artikelart varchar(100) = null
AS
BEGIN
	SELECT * FROM dbo.almait06_Artikel
	WHERE (ArtikelID = @ArtikelID OR @ArtikelID IS NULL)
	AND (LadenID = @LadenID OR @LadenID IS NULL)
	AND (Artikelart = @Artikelart OR @Artikelart IS NULL)
END
go

