Create trigger dbo.Arnold_insert
on dbo.Arnold_Schokolade
after insert
as begin
		set nocount on
		insert into dbo.Arnold_log 
		select SUSER_NAME(), CURRENT_TIMESTAMP, Name, Artikelnr, Kakaogehalt, Besonderheit, Preis_je_Stk, Lagerbestand
		from inserted
		end
go

