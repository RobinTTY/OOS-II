CREATE FUNCTION dbo.almait06_Function_Checkdate
(
	@ArtikelID int
)
RETURNS INT
AS
BEGIN
	declare @kaufdatum datetime = (select Kaufdatum from dbo.almait06_Bestand where ArtikelID = @ArtikelID)
	declare @heute datetime
	declare @hilfsVar int
	declare @ergebnis int

	set @heute = GETDATE()
	set @hilfsVar=Datediff(day, @kaufdatum , @heute)


	--Artikel ist NOK
	if @hilfsVar > 14
		set @ergebnis = 1
		

	--Heute gekauft
    if @hilfsVar = 0
		set @ergebnis = 2
		
	
	--Artikel ist OK
	if @hilfsVar < 14
		set @ergebnis = 3

	return @ergebnis
END
go

