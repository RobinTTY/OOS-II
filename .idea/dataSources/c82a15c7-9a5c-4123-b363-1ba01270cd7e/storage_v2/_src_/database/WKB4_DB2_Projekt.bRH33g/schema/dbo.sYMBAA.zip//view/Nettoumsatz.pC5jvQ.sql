create view Nettoumsatz as

select sum(m.Stundensatz * p.Stundenanzahl) as Gesamt
from nisiit00_Mitarbeiter as m
join  nisiit00_Position as p
on m.MNr = p.MNr;
go

