
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE dbo.sabait01_addTeam 
	-- Add the parameters for the stored procedure here
	@teamId int,
	@teamName nchar(30)

AS
INSERT INTO dbo.sabait01_team VALUES (@teamId, @teamName);
go

