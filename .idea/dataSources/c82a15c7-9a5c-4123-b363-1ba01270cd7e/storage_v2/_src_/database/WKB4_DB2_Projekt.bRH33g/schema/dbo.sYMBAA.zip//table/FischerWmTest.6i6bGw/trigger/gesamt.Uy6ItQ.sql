-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER gesamt
ON [dbo].[FischerWmTest]
AFTER INSERT
AS
BEGIN
SET NOCOUNT ON
DECLARE @Name nvarchar(50)
DECLARE @Vorname nvarchar(50)
DECLARE @Datum datetime

SET @Name =(SELECT Nachname from inserted)
SET @Vorname =(SELECT Vorname from inserted)
SET @Datum =GETDATE()
INSERT INTO dbo.FischerBackup
VALUES (@Name,@Vorname,@Datum)



 
END
go

