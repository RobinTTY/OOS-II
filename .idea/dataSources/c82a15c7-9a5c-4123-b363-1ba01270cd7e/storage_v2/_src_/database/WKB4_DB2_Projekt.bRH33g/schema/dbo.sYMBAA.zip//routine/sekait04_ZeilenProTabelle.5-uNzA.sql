create FUNCTION sekait04_ZeilenProTabelle
(  @param1 varchar(31) )  
RETURNS INT  
AS  
BEGIN   
declare @ergebnis int = NULL;  
IF @param1 = 'Mitglieder'   
SELECT @ergebnis = COUNT(*) FROM sekait04_Mitglieder;  
ELSE IF @param1 = 'Trainer'   
SELECT @ergebnis = COUNT(*) FROM sekait04_Trainer;  
ELSE   
SELECT @ergebnis = COUNT(*) FROM sekait04_Termin;  
RETURN @ergebnis; 
END
go

