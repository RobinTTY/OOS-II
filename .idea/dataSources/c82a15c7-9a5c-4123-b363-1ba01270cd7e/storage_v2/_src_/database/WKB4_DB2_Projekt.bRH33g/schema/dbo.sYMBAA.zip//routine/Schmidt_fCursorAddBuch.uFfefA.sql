CREATE function dbo.Schmidt_fCursorAddBuch
(@AAutor VARCHAR(50), @TTitel VARCHAR(100))

returns int

as 
begin
	declare @pruf as int
	declare @Autor VARCHAR(50)
	declare @Titel VARCHAR(100)

	set @Autor = (select Autor from Schmidt_Buch)
	set @Titel = (select Titel from Schmidt_Buch)

	if (@Autor=@AAutor) and (@Titel=@TTitel)
		begin
		set @pruf=1;
		end
	else 
		begin
		set @pruf=0;
		end
	return @pruf
end
go

