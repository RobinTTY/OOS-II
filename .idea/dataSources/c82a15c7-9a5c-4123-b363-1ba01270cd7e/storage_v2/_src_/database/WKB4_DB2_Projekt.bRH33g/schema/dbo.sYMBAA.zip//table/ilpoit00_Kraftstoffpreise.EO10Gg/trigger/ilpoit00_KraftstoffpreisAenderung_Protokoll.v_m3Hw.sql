create trigger dbo.ilpoit00_KraftstoffpreisAenderung_Protokoll
on WKB4_DB2_Projekt.dbo.ilpoit00_Kraftstoffpreise
After Update

AS
Begin
	set nocount on;
	Insert Into dbo.ilpoit00_KraftstoffpreisAenderungen (StationsID, KraftstoffNr, PreisAktuell, Aenderungszeitpunkt)
		Select StationsID, KraftstoffNr, KraftstoffPreis, CURRENT_TIMESTAMP
	From dbo.ilpoit00_Kraftstoffpreise
End
go

